import { createClient } from "@supabase/supabase-js";

import type {
  AdminProfile,
  Course,
  Enrollment,
  Parent,
  PrototypeData,
  Student,
  Teacher,
} from "@/components/myschool-app";

const studentGradients = [
  "from-[#4f8cff] to-[#a78bfa]",
  "from-[#a78bfa] to-[#34d399]",
  "from-[#34d399] to-[#4f8cff]",
  "from-[#fb923c] to-[#a78bfa]",
  "from-[#4f8cff] to-[#fb923c]",
];

const teacherGradients = [
  "from-[#34d399] to-[#4f8cff]",
  "from-[#a78bfa] to-[#fb923c]",
  "from-[#4f8cff] to-[#34d399]",
];

const courseAccents = [
  "bg-[rgba(79,140,255,0.12)] text-[#4f8cff]",
  "bg-[rgba(167,139,250,0.12)] text-[#a78bfa]",
  "bg-[rgba(52,211,153,0.12)] text-[#34d399]",
  "bg-[rgba(251,146,60,0.12)] text-[#fb923c]",
  "bg-[rgba(79,140,255,0.12)] text-[#4f8cff]",
];

function initials(...parts: string[]) {
  return parts
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

function fullName(first?: string, last?: string) {
  return [first, last].filter(Boolean).join(" ");
}

export async function getPrototypeData(): Promise<PrototypeData | null> {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!supabaseUrl || !supabaseAnonKey) {
    return null;
  }

  const supabase = createClient(supabaseUrl, supabaseAnonKey);

  const [
    parentResult,
    studentResult,
    teacherResult,
    adminResult,
    courseResult,
    enrollmentResult,
  ] = await Promise.all([
    supabase.from("parent").select("*").order("num", { ascending: true }),
    supabase.from("student").select("*").order("id", { ascending: true }),
    supabase.from("teacher").select("*").order("id", { ascending: true }),
    supabase.from("admin").select("id, fname, lname").order("id", { ascending: true }),
    supabase.from("course").select("*").order("id", { ascending: true }),
    supabase.from("enrollment").select("*").order("student_id", { ascending: true }),
  ]);

  if (
    parentResult.error ||
    studentResult.error ||
    teacherResult.error ||
    adminResult.error ||
    courseResult.error ||
    enrollmentResult.error
  ) {
    return null;
  }

  const parentRows = parentResult.data ?? [];
  const studentRows = studentResult.data ?? [];
  const teacherRows = teacherResult.data ?? [];
  const adminRows = adminResult.data ?? [];
  const courseRows = courseResult.data ?? [];
  const enrollmentRows = enrollmentResult.data ?? [];

  const parentMap = new Map<number, (typeof parentRows)[number]>(
    parentRows.map((parent) => [parent.num, parent]),
  );

  const adminMap = new Map<number, string>(
    adminRows.map((admin) => [admin.id, fullName(admin.fname, admin.lname)]),
  );

  const studentCourseMap = new Map<number, string[]>();
  for (const row of enrollmentRows) {
    const current = studentCourseMap.get(row.student_id) ?? [];
    const matchingCourse = courseRows.find((course) => course.id === row.course_id);
    if (matchingCourse) {
      current.push(`${matchingCourse.name} #${matchingCourse.id}`);
    }
    studentCourseMap.set(row.student_id, current);
  }

  const students: Student[] = studentRows.map((student, index) => ({
    id: student.id,
    firstName: student.fname,
    middleName: student.mname ?? "",
    lastName: student.lname,
    email: student.email,
    gpa: Number(student.gpa),
    parentName: parentMap.get(student.parent_num)?.parent_name ?? "No parent linked",
    relationship:
      parentMap.get(student.parent_num)?.relationship_with_student ?? "Unknown",
    initials: initials(student.fname, student.lname),
    gradient: studentGradients[index % studentGradients.length],
    status: index === 2 ? "Active" : "Enrolled",
    courses: studentCourseMap.get(student.id) ?? [],
  }));

  const teachers: Teacher[] = teacherRows.map((teacher, index) => {
    const matchingCourse = courseRows.find((course) => course.teacher_id === teacher.id);
    return {
      id: teacher.id,
      name: fullName(teacher.fname, teacher.lname),
      email: teacher.email,
      phone: teacher.phone ?? "",
      course: matchingCourse?.name ?? "Unassigned",
      admin: adminMap.get(teacher.admin_id) ?? "Unknown",
      initials: initials(teacher.fname, teacher.lname),
      gradient: teacherGradients[index % teacherGradients.length],
    };
  });

  const courses: Course[] = courseRows.map((course, index) => {
    const matchingTeacher = teacherRows.find((teacher) => teacher.id === course.teacher_id);
    return {
      id: course.id,
      name: course.name,
      teacher: matchingTeacher
        ? fullName(matchingTeacher.fname, matchingTeacher.lname)
        : "Unassigned",
      admin: adminMap.get(course.admin_id) ?? "Unknown",
      enrolled: enrollmentRows.filter((row) => row.course_id === course.id).length,
      accent: courseAccents[index % courseAccents.length],
    };
  });

  const parentStudentMap = new Map<number, string[]>();
  for (const student of students) {
    const current = parentStudentMap.get(
      studentRows.find((row) => row.id === student.id)?.parent_num ?? -1,
    ) ?? [];
    current.push(`${student.firstName} ${student.lastName}`);
    const parentNum = studentRows.find((row) => row.id === student.id)?.parent_num;
    if (parentNum) {
      parentStudentMap.set(parentNum, current);
    }
  }

  const parentSeen = new Set<number>();
  const parents: Parent[] = parentRows
    .filter((row) => !parentSeen.has(row.num))
    .map((row) => {
      parentSeen.add(row.num);
      return {
        id: row.num,
        name: row.parent_name ?? "Unknown",
        relationship: row.relationship_with_student ?? "Unknown",
        studentNames: (parentStudentMap.get(row.num) ?? []).join(", "),
      };
    });

  const enrollments: Enrollment[] = enrollmentRows.slice(0, 8).map((row) => {
    const student = students.find((item) => item.id === row.student_id);
    const course = courses.find((item) => item.id === row.course_id);
    return {
      student: student ? `${student.firstName} ${student.lastName}` : `#${row.student_id}`,
      course: course?.name ?? `#${row.course_id}`,
      badge:
        row.course_id % 3 === 0
          ? "badge-green"
          : row.course_id % 2 === 0
            ? "badge-purple"
            : "badge-blue",
    };
  });

  const admins: AdminProfile[] = adminRows.map((admin) => ({
    id: admin.id,
    name: fullName(admin.fname, admin.lname),
  }));

  return {
    stats: {
      totalStudents: students.length,
      totalTeachers: teachers.length,
      totalCourses: courses.length,
      totalEnrollments: enrollmentRows.length,
    },
    students,
    teachers,
    courses,
    parents,
    enrollments,
    admins,
  };
}
