"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import type { JSX, ReactNode } from "react";
import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";

import { getBrowserSupabaseClient } from "@/lib/supabase/browser";

type PageId =
  | "dashboard"
  | "students"
  | "teachers"
  | "courses"
  | "enrollment"
  | "parents";

type Role = "Admin" | "Teacher" | "Student" | "Parent";
type ModalId =
  | "addStudent"
  | "viewStudent"
  | "addTeacher"
  | "addCourse"
  | null;

type SidebarItem = {
  id: PageId;
  section: string;
  icon: JSX.Element;
};

export type Student = {
  id: number;
  firstName: string;
  middleName: string;
  lastName: string;
  email: string;
  gpa: number;
  parentName: string;
  relationship: string;
  initials: string;
  gradient: string;
  status: string;
  courses: string[];
};

export type Teacher = {
  id: number;
  name: string;
  email: string;
  phone: string;
  course: string;
  admin: string;
  initials: string;
  gradient: string;
};

export type Course = {
  id: number;
  name: string;
  teacher: string;
  admin: string;
  enrolled: number;
  accent: string;
};

export type Parent = {
  id: number;
  name: string;
  relationship: string;
  studentNames: string;
};

export type Enrollment = {
  student: string;
  course: string;
  badge: string;
};

export type AdminProfile = {
  id: number;
  name: string;
};

export type PrototypeData = {
  stats: {
    totalStudents: number;
    totalTeachers: number;
    totalCourses: number;
    totalEnrollments: number;
  };
  students: Student[];
  teachers: Teacher[];
  courses: Course[];
  parents: Parent[];
  enrollments: Enrollment[];
  admins: AdminProfile[];
};

const roleLabels: Record<Role, string> = {
  Admin: "Administrator",
  Teacher: "Teacher",
  Student: "Student",
  Parent: "Parent",
};

const students: Student[] = [
  {
    id: 22201,
    firstName: "Layan",
    middleName: "A",
    lastName: "Alotaibi",
    email: "layan1@mail.com",
    gpa: 3.5,
    parentName: "Saud Alotaibi",
    relationship: "Father",
    initials: "LA",
    gradient: "from-[#4f8cff] to-[#a78bfa]",
    status: "Enrolled",
    courses: ["Math #401", "English #402"],
  },
  {
    id: 22202,
    firstName: "Reem",
    middleName: "B",
    lastName: "Almutairi",
    email: "reem2@mail.com",
    gpa: 3.8,
    parentName: "Noura Almutairi",
    relationship: "Mother",
    initials: "RA",
    gradient: "from-[#a78bfa] to-[#34d399]",
    status: "Enrolled",
    courses: ["English #402", "Science #403"],
  },
  {
    id: 22203,
    firstName: "Nada",
    middleName: "C",
    lastName: "Alqahtani",
    email: "nada3@mail.com",
    gpa: 4,
    parentName: "Khalid Alqahtani",
    relationship: "Father",
    initials: "NA",
    gradient: "from-[#34d399] to-[#4f8cff]",
    status: "Active",
    courses: ["Math #401", "History #404"],
  },
  {
    id: 22204,
    firstName: "Huda",
    middleName: "D",
    lastName: "Alanazi",
    email: "huda4@mail.com",
    gpa: 3.2,
    parentName: "Maha Alanazi",
    relationship: "Mother",
    initials: "HA",
    gradient: "from-[#fb923c] to-[#a78bfa]",
    status: "Enrolled",
    courses: ["Physics #405", "Math #401"],
  },
  {
    id: 22205,
    firstName: "Rana",
    middleName: "E",
    lastName: "Alharbi",
    email: "rana5@mail.com",
    gpa: 3.6,
    parentName: "Fahad Alharbi",
    relationship: "Father",
    initials: "RA",
    gradient: "from-[#4f8cff] to-[#fb923c]",
    status: "Enrolled",
    courses: ["Chemistry #406", "English #402"],
  },
];

const teachers: Teacher[] = [
  {
    id: 30001,
    name: "Fatimah Ali",
    email: "fatimah@mail.com",
    phone: "0501111111",
    course: "Math",
    admin: "Sara Ali",
    initials: "FA",
    gradient: "from-[#34d399] to-[#4f8cff]",
  },
  {
    id: 30002,
    name: "Aisha Hassan",
    email: "aisha@mail.com",
    phone: "0502222222",
    course: "English",
    admin: "Noor Hassan",
    initials: "AH",
    gradient: "from-[#a78bfa] to-[#fb923c]",
  },
  {
    id: 30003,
    name: "Nora Khalid",
    email: "nora@mail.com",
    phone: "0503333333",
    course: "Science",
    admin: "Lama Khalid",
    initials: "NK",
    gradient: "from-[#4f8cff] to-[#34d399]",
  },
];

const courses: Course[] = [
  {
    id: 401,
    name: "Mathematics",
    teacher: "Fatimah Ali",
    admin: "Sara Ali",
    enrolled: 3,
    accent: "bg-[rgba(79,140,255,0.12)] text-[#4f8cff]",
  },
  {
    id: 402,
    name: "English",
    teacher: "Aisha Hassan",
    admin: "Noor Hassan",
    enrolled: 3,
    accent: "bg-[rgba(167,139,250,0.12)] text-[#a78bfa]",
  },
  {
    id: 403,
    name: "Science",
    teacher: "Nora Khalid",
    admin: "Lama Khalid",
    enrolled: 2,
    accent: "bg-[rgba(52,211,153,0.12)] text-[#34d399]",
  },
  {
    id: 404,
    name: "History",
    teacher: "Lama Saad",
    admin: "Reem Saad",
    enrolled: 2,
    accent: "bg-[rgba(251,146,60,0.12)] text-[#fb923c]",
  },
  {
    id: 405,
    name: "Physics",
    teacher: "Reem Fahad",
    admin: "Huda Fahad",
    enrolled: 2,
    accent: "bg-[rgba(79,140,255,0.12)] text-[#4f8cff]",
  },
];

const parents: Parent[] = [
  {
    id: 50001,
    name: "Saud Alotaibi",
    relationship: "Father",
    studentNames: "Layan Alotaibi",
  },
  {
    id: 50002,
    name: "Noura Almutairi",
    relationship: "Mother",
    studentNames: "Reem Almutairi",
  },
  {
    id: 50003,
    name: "Khalid Alqahtani",
    relationship: "Father",
    studentNames: "Nada Alqahtani",
  },
  {
    id: 50004,
    name: "Maha Alanazi",
    relationship: "Mother",
    studentNames: "Huda Alanazi",
  },
  {
    id: 50005,
    name: "Fahad Alharbi",
    relationship: "Father",
    studentNames: "Rana Alharbi",
  },
];

const enrollmentRows: Enrollment[] = [
  { student: "Layan Alotaibi", course: "Math", badge: "badge-blue" },
  { student: "Layan Alotaibi", course: "English", badge: "badge-purple" },
  { student: "Reem Almutairi", course: "English", badge: "badge-purple" },
  { student: "Reem Almutairi", course: "Science", badge: "badge-green" },
  { student: "Nada Alqahtani", course: "Math", badge: "badge-blue" },
];

const adminProfiles: AdminProfile[] = [
  { id: 10001, name: "Sara Ali" },
  { id: 10002, name: "Noor Hassan" },
  { id: 10003, name: "Lama Khalid" },
  { id: 10004, name: "Reem Saad" },
  { id: 10005, name: "Huda Fahad" },
  { id: 10006, name: "Abeer Nasser" },
  { id: 10007, name: "Maha Omar" },
  { id: 10008, name: "Dalia Salem" },
  { id: 10009, name: "Rana Tariq" },
  { id: 10010, name: "Eman Adel" },
];

function DashboardIcon() {
  return (
    <svg className="h-[18px] w-[18px]" viewBox="0 0 20 20" fill="currentColor">
      <path d="M2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V4ZM2 13a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-3ZM11 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2V4ZM11 13a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2v-3Z" />
    </svg>
  );
}

function StudentsIcon() {
  return (
    <svg className="h-[18px] w-[18px]" viewBox="0 0 20 20" fill="currentColor">
      <path d="M10 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM6 8a2 2 0 1 1-4 0 2 2 0 0 1 4 0ZM1.49 15.326a.78.78 0 0 1-.358-.442 3 3 0 0 1 4.308-3.516 6.484 6.484 0 0 0-1.905 3.959c-.023.222-.014.442.025.654a4.97 4.97 0 0 1-2.07-.655ZM16.44 15.98a4.97 4.97 0 0 0 2.07-.654.78.78 0 0 0 .357-.442 3 3 0 0 0-4.308-3.517 6.484 6.484 0 0 1 1.907 3.96 2.32 2.32 0 0 1-.026.654ZM18 8a2 2 0 1 1-4 0 2 2 0 0 1 4 0ZM5.304 16.19a.844.844 0 0 1-.277-.71 5 5 0 0 1 9.947 0 .843.843 0 0 1-.277.71A6.975 6.975 0 0 1 10 18a6.974 6.974 0 0 1-4.696-1.81Z" />
    </svg>
  );
}

function TeacherIcon() {
  return (
    <svg className="h-[18px] w-[18px]" viewBox="0 0 20 20" fill="currentColor">
      <path
        fillRule="evenodd"
        d="M10 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm-7 9a7 7 0 1 1 14 0H3Z"
        clipRule="evenodd"
      />
    </svg>
  );
}

function BookIcon() {
  return (
    <svg className="h-[18px] w-[18px]" viewBox="0 0 20 20" fill="currentColor">
      <path d="M9 4.804A7.968 7.968 0 0 0 5.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 0 1 5.5 14c1.669 0 3.218.51 4.5 1.385A7.962 7.962 0 0 1 14.5 14c1.255 0 2.443.29 3.5.804v-10A7.968 7.968 0 0 0 14.5 4c-1.255 0-2.443.29-3.5.804V12a1 1 0 1 1-2 0V4.804Z" />
    </svg>
  );
}

function EnrollmentIcon() {
  return (
    <svg className="h-[18px] w-[18px]" viewBox="0 0 20 20" fill="currentColor">
      <path d="M8 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM8 11a6 6 0 0 1 6 6H2a6 6 0 0 1 6-6ZM16 7a1 1 0 1 0-2 0v1h-1a1 1 0 1 0 0 2h1v1a1 1 0 1 0 2 0v-1h1a1 1 0 1 0 0-2h-1V7Z" />
    </svg>
  );
}

function ParentsIcon() {
  return (
    <svg className="h-[18px] w-[18px]" viewBox="0 0 20 20" fill="currentColor">
      <path d="M13 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM18 8a2 2 0 1 1-4 0 2 2 0 0 1 4 0ZM14 15a4 4 0 0 0-8 0v3h8v-3ZM6 8a2 2 0 1 1-4 0 2 2 0 0 1 4 0ZM16 18v-3a5.972 5.972 0 0 0-.75-2.906A3.005 3.005 0 0 1 19 15v3h-3ZM4.75 12.094A5.973 5.973 0 0 0 4 15v3H1v-3a3 3 0 0 1 3.75-2.906Z" />
    </svg>
  );
}

function SearchIcon() {
  return (
    <svg className="h-[13px] w-[13px]" viewBox="0 0 20 20" fill="currentColor">
      <path
        fillRule="evenodd"
        d="M8 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8ZM2 8a6 6 0 1 1 10.89 3.476l4.817 4.817a1 1 0 0 1-1.414 1.414l-4.816-4.816A6 6 0 0 1 2 8Z"
        clipRule="evenodd"
      />
    </svg>
  );
}

function BellIcon() {
  return (
    <svg className="h-[15px] w-[15px]" viewBox="0 0 20 20" fill="currentColor">
      <path d="M10 2a6 6 0 0 0-6 6v3.586l-.707.707A1 1 0 0 0 4 14h12a1 1 0 0 0 .707-1.707L16 11.586V8a6 6 0 0 0-6-6ZM10 18a3 3 0 0 1-3-3h6a3 3 0 0 1-3 3Z" />
    </svg>
  );
}

const sidebarItems: SidebarItem[] = [
  { id: "dashboard", section: "Overview", icon: <DashboardIcon /> },
  { id: "students", section: "Academic", icon: <StudentsIcon /> },
  { id: "teachers", section: "Academic", icon: <TeacherIcon /> },
  { id: "courses", section: "Academic", icon: <BookIcon /> },
  { id: "enrollment", section: "Management", icon: <EnrollmentIcon /> },
  { id: "parents", section: "Family", icon: <ParentsIcon /> },
];

const rolePageAccess: Record<Role, PageId[]> = {
  Admin: ["dashboard", "students", "teachers", "courses", "enrollment", "parents"],
  Teacher: ["dashboard", "students", "teachers", "courses"],
  Student: ["dashboard", "students", "courses"],
  Parent: ["dashboard", "students", "courses", "parents"],
};

const toneClasses = {
  blue: {
    card: "after:bg-[#4f8cff]",
    icon: "bg-[rgba(79,140,255,0.12)] text-[#4f8cff]",
  },
  purple: {
    card: "after:bg-[#a78bfa]",
    icon: "bg-[rgba(167,139,250,0.12)] text-[#a78bfa]",
  },
  green: {
    card: "after:bg-[#34d399]",
    icon: "bg-[rgba(52,211,153,0.12)] text-[#34d399]",
  },
  orange: {
    card: "after:bg-[#fb923c]",
    icon: "bg-[rgba(251,146,60,0.12)] text-[#fb923c]",
  },
} as const;

function inputClassName() {
  return "w-full rounded-lg border border-white/[0.07] bg-[#0a0c10] px-3.5 py-2.5 text-[0.88rem] text-[#f0f2f7] outline-none transition placeholder:text-[#6b7280] focus:border-[#4f8cff]";
}

function normalizeRole(value: unknown): Role | null {
  if (
    value === "Admin" ||
    value === "Teacher" ||
    value === "Student" ||
    value === "Parent"
  ) {
    return value;
  }

  return null;
}

function titleCaseEmailName(email?: string | null) {
  if (!email) return "MySchool User";

  const base = email.split("@")[0]?.replace(/[._-]+/g, " ").trim();
  if (!base) return "MySchool User";

  return base
    .split(" ")
    .filter(Boolean)
    .map((part) => part[0].toUpperCase() + part.slice(1))
    .join(" ");
}

function initialsFromName(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

type UserProfileMetadata = {
  role?: Role;
  profileId?: number;
  parentNum?: number;
};

type StudentFormState = {
  firstName: string;
  middleName: string;
  lastName: string;
  gpa: string;
  parentName: string;
  relationship: string;
};

type TeacherFormState = {
  firstName: string;
  lastName: string;
  phone: string;
  adminId: string;
};

type ParentFormState = {
  parentName: string;
  relationship: string;
};

const emptyStudentForm: StudentFormState = {
  firstName: "",
  middleName: "",
  lastName: "",
  gpa: "",
  parentName: "",
  relationship: "",
};

const emptyTeacherForm: TeacherFormState = {
  firstName: "",
  lastName: "",
  phone: "",
  adminId: "",
};

const emptyParentForm: ParentFormState = {
  parentName: "",
  relationship: "",
};

function getUserProfileMetadata(user: User | null): UserProfileMetadata {
  return (user?.user_metadata ?? {}) as UserProfileMetadata;
}

function normalizeText(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "");
}

function studentFullName(student: Student) {
  return `${student.firstName} ${student.lastName}`;
}

function pageLabel(role: Role, page: PageId) {
  const labels: Record<Role, Record<PageId, string>> = {
    Admin: {
      dashboard: "Dashboard",
      students: "Students",
      teachers: "Teachers",
      courses: "Courses",
      enrollment: "Enrollment",
      parents: "Parents",
    },
    Teacher: {
      dashboard: "Teacher Dashboard",
      students: "My Students",
      teachers: "My Profile",
      courses: "My Courses",
      enrollment: "Enrollment",
      parents: "Parents",
    },
    Student: {
      dashboard: "Student Dashboard",
      students: "My Profile",
      teachers: "Teachers",
      courses: "My Courses",
      enrollment: "Enrollment",
      parents: "Parents",
    },
    Parent: {
      dashboard: "Parent Dashboard",
      students: "My Children",
      teachers: "Teachers",
      courses: "Family Courses",
      enrollment: "Enrollment",
      parents: "Parent Profile",
    },
  };

  return labels[role][page];
}

function pageSubtitle(role: Role, page: PageId) {
  const subtitles: Record<Role, Record<PageId, string>> = {
    Admin: {
      dashboard: "Manage the full school system from one place.",
      students: "Manage all student records.",
      teachers: "Manage teacher records and course assignments.",
      courses: "View and manage all school courses.",
      enrollment: "Enroll students into courses.",
      parents: "Parent contact records linked to students.",
    },
    Teacher: {
      dashboard: "Track your classes, students, and teaching load.",
      students: "Students currently linked to your assigned courses.",
      teachers: "Your faculty profile and assignment details.",
      courses: "Courses currently assigned to you.",
      enrollment: "Enrollment",
      parents: "Parents",
    },
    Student: {
      dashboard: "Your personal academic summary.",
      students: "Your student profile from the school database.",
      teachers: "Teachers",
      courses: "The courses you are currently enrolled in.",
      enrollment: "Enrollment",
      parents: "Parents",
    },
    Parent: {
      dashboard: "A quick overview of your linked student records.",
      students: "Students connected to your parent account.",
      teachers: "Teachers",
      courses: "Courses taken by your linked students.",
      enrollment: "Enrollment",
      parents: "Your contact information from the parent table.",
    },
  };

  return subtitles[role][page];
}

function badgeToneFromEnrollment(row: Enrollment) {
  if (row.badge === "badge-blue") return "blue";
  if (row.badge === "badge-purple") return "purple";
  return "green";
}

function studentHasCourse(student: Student, course: Course) {
  const courseName = normalizeText(course.name);
  return student.courses.some((entry) => normalizeText(entry).includes(courseName));
}

function resolveStudentForUser(currentUser: User | null, studentRows: Student[]) {
  if (!currentUser) return studentRows[0];

  const metadata = getUserProfileMetadata(currentUser);
  const email = currentUser?.email?.toLowerCase() ?? "";
  const name = titleCaseEmailName(currentUser?.email);

  return (
    studentRows.find((student) => student.id === metadata.profileId) ??
    studentRows.find((student) => student.email.toLowerCase() === email) ??
    studentRows.find((student) => normalizeText(studentFullName(student)) === normalizeText(name)) ??
    null
  );
}

function resolveTeacherForUser(currentUser: User | null, teacherRows: Teacher[]) {
  if (!currentUser) return teacherRows[0];

  const metadata = getUserProfileMetadata(currentUser);
  const email = currentUser?.email?.toLowerCase() ?? "";
  const name = titleCaseEmailName(currentUser?.email);

  return (
    teacherRows.find((teacher) => teacher.id === metadata.profileId) ??
    teacherRows.find((teacher) => teacher.email.toLowerCase() === email) ??
    teacherRows.find((teacher) => normalizeText(teacher.name) === normalizeText(name)) ??
    null
  );
}

function resolveParentForUser(currentUser: User | null, parentRows: Parent[]) {
  if (!currentUser) return parentRows[0];

  const metadata = getUserProfileMetadata(currentUser);
  const name = titleCaseEmailName(currentUser?.email);

  return (
    parentRows.find((parent) => parent.id === metadata.parentNum || parent.id === metadata.profileId) ??
    parentRows.find((parent) => normalizeText(parent.name) === normalizeText(name)) ??
    null
  );
}

function groupSidebar(items: SidebarItem[]) {
  return items.reduce<Record<string, SidebarItem[]>>((acc, item) => {
    acc[item.section] ??= [];
    acc[item.section].push(item);
    return acc;
  }, {});
}

async function getNextNumericId(
  supabase: NonNullable<ReturnType<typeof getBrowserSupabaseClient>>,
  table: "student" | "teacher" | "parent",
  column: "id" | "num",
) {
  const { data, error } = await supabase
    .from(table)
    .select(column)
    .order(column, { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    throw new Error(`Failed to prepare a new ${table} record.`);
  }

  const row = data as Record<string, unknown> | null;
  const currentValue = Number(row?.[column] ?? 0);
  return currentValue + 1;
}

function StatCard({
  label,
  value,
  tone,
  icon,
}: {
  label: string;
  value: string;
  tone: keyof typeof toneClasses;
  icon: ReactNode;
}) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-white/[0.07] bg-[#11141a] p-5 transition hover:border-white/[0.15] after:absolute after:right-0 after:top-0 after:h-20 after:w-20 after:translate-x-[30%] after:-translate-y-[30%] after:rounded-full after:opacity-[0.07]">
      <div
        className={`mb-3.5 flex h-9 w-9 items-center justify-center rounded-lg ${toneClasses[tone].icon} ${toneClasses[tone].card}`}
      >
        {icon}
      </div>
      <div className="font-display text-[1.8rem] font-bold leading-none">{value}</div>
      <div className="mt-1 text-[0.78rem] text-[#6b7280]">{label}</div>
    </div>
  );
}

function SummaryCard({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <div className="rounded-xl border border-white/[0.07] bg-[#11141a] p-5">
      <div className="mb-4 font-display text-[0.95rem] font-semibold">{title}</div>
      {children}
    </div>
  );
}

export function MySchoolApp({
  initialData,
}: {
  initialData?: PrototypeData;
}) {
  const router = useRouter();
  const supabase = getBrowserSupabaseClient();
  const [role, setRole] = useState<Role>("Admin");
  const [page, setPage] = useState<PageId>("dashboard");
  const [loggedIn, setLoggedIn] = useState(false);
  const [modal, setModal] = useState<ModalId>(null);
  const [authMode, setAuthMode] = useState<"signIn" | "signUp">("signIn");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authLoading, setAuthLoading] = useState(false);
  const [authMessage, setAuthMessage] = useState("");
  const [authError, setAuthError] = useState("");
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [studentForm, setStudentForm] = useState<StudentFormState>(emptyStudentForm);
  const [teacherForm, setTeacherForm] = useState<TeacherFormState>(emptyTeacherForm);
  const [parentForm, setParentForm] = useState<ParentFormState>(emptyParentForm);
  const [profileSaving, setProfileSaving] = useState(false);
  const [profileError, setProfileError] = useState("");

  const studentsData = initialData?.students ?? students;
  const teachersData = initialData?.teachers ?? teachers;
  const coursesData = initialData?.courses ?? courses;
  const parentsData = initialData?.parents ?? parents;
  const enrollmentsData = initialData?.enrollments ?? enrollmentRows;
  const adminsData = initialData?.admins ?? adminProfiles;
  const statsData = initialData?.stats ?? {
    totalStudents: students.length,
    totalTeachers: teachers.length,
    totalCourses: courses.length,
    totalEnrollments: enrollmentRows.length,
  };

  const activeRole = normalizeRole(currentUser?.user_metadata?.role) ?? role;
  const currentUserMetadata = getUserProfileMetadata(currentUser);
  const currentUserName = titleCaseEmailName(currentUser?.email);
  const currentUserInitials = initialsFromName(currentUserName) || "MS";

  const allowedPages = rolePageAccess[activeRole];
  const visibleSidebarItems = sidebarItems.filter((item) => allowedPages.includes(item.id));
  const groupedSidebar = groupSidebar(visibleSidebarItems);

  const featuredStudent = resolveStudentForUser(currentUser, studentsData);
  const activeTeacher = resolveTeacherForUser(currentUser, teachersData);
  const activeParent = resolveParentForUser(currentUser, parentsData);
  const parentStudentNames = activeParent?.studentNames
    .split(",")
    .map((name) => name.trim())
    .filter(Boolean) ?? [];
  const parentStudents = studentsData.filter((student) =>
    parentStudentNames.includes(studentFullName(student)),
  );
  const studentCourses = featuredStudent
    ? coursesData.filter((course) => studentHasCourse(featuredStudent, course))
    : [];
  const teacherCourses = activeTeacher
    ? coursesData.filter(
        (course) =>
          normalizeText(course.teacher) === normalizeText(activeTeacher.name) ||
          normalizeText(course.name).includes(normalizeText(activeTeacher.course)),
      )
    : [];
  const teacherStudents = studentsData.filter((student) =>
    teacherCourses.some((course) => studentHasCourse(student, course)),
  );
  const familyCourses = coursesData.filter((course) =>
    parentStudents.some((student) => studentHasCourse(student, course)),
  );
  const familyEnrollments = enrollmentsData.filter((row) =>
    parentStudents.some((student) => row.student === studentFullName(student)),
  );
  const teacherEnrollmentCount = enrollmentsData.filter((row) =>
    teacherCourses.some((course) =>
      normalizeText(row.course).includes(normalizeText(course.name)),
    ),
  ).length;
  const profileMissing =
    loggedIn &&
    ((activeRole === "Student" && !featuredStudent) ||
      (activeRole === "Teacher" && !activeTeacher) ||
      (activeRole === "Parent" && !activeParent));

  useEffect(() => {
    if (!supabase) return;

    let mounted = true;

    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;

      if (data.session?.user) {
        setCurrentUser(data.session.user);
        const sessionRole = normalizeRole(data.session.user.user_metadata?.role);
        if (sessionRole) {
          setRole(sessionRole);
        }
        setLoggedIn(true);
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setCurrentUser(session?.user ?? null);
      const sessionRole = normalizeRole(session?.user?.user_metadata?.role);
      if (sessionRole) {
        setRole(sessionRole);
      }
      setLoggedIn(Boolean(session?.user));
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [supabase]);

  useEffect(() => {
    if (!allowedPages.includes(page)) {
      setPage("dashboard");
    }
  }, [allowedPages, page]);

  useEffect(() => {
    if (activeRole !== "Admin" && modal) {
      setModal(null);
    }
  }, [activeRole, modal]);

  function resetRoleForms() {
    setStudentForm(emptyStudentForm);
    setTeacherForm(emptyTeacherForm);
    setParentForm(emptyParentForm);
    setProfileError("");
  }

  function validateProfileForm(selectedRole: Role) {
    if (selectedRole === "Student") {
      if (
        !studentForm.firstName.trim() ||
        !studentForm.lastName.trim() ||
        !studentForm.gpa.trim() ||
        !studentForm.parentName.trim() ||
        !studentForm.relationship.trim()
      ) {
        return "Students must complete all profile fields before creating an account.";
      }
    }

    if (selectedRole === "Teacher") {
      if (
        !teacherForm.firstName.trim() ||
        !teacherForm.lastName.trim() ||
        !teacherForm.phone.trim() ||
        !teacherForm.adminId.trim()
      ) {
        return "Teachers must complete all profile fields before creating an account.";
      }
    }

    if (selectedRole === "Parent") {
      if (!parentForm.parentName.trim() || !parentForm.relationship.trim()) {
        return "Parents must complete all profile fields before creating an account.";
      }
    }

    return null;
  }

  async function saveProfileRecord(user: User | null, selectedRole: Role) {
    if (!supabase) {
      throw new Error("Supabase is not configured yet. Add the environment variables first.");
    }

    const metadata = getUserProfileMetadata(user);
    const emailAddress = user?.email ?? email.trim();
    if (!emailAddress) {
      throw new Error("An email address is required to save this profile.");
    }

    if (selectedRole === "Student") {
      const studentId =
        metadata.profileId ??
        (await getNextNumericId(supabase, "student", "id"));
      const parentNum =
        metadata.parentNum ?? (await getNextNumericId(supabase, "parent", "num"));

      const { error: parentError } = await supabase.from("parent").upsert({
        num: parentNum,
        parent_name: studentForm.parentName.trim(),
        relationship_with_student: studentForm.relationship.trim(),
      });

      if (parentError) {
        throw new Error(parentError.message);
      }

      const { error: studentError } = await supabase.from("student").upsert({
        id: studentId,
        fname: studentForm.firstName.trim(),
        mname: studentForm.middleName.trim() || null,
        lname: studentForm.lastName.trim(),
        email: emailAddress,
        gpa: Number(studentForm.gpa),
        parent_num: parentNum,
      });

      if (studentError) {
        throw new Error(studentError.message);
      }

      if (user) {
        const { data: updatedUserData, error: updateUserError } = await supabase.auth.updateUser({
          data: {
            role: selectedRole,
            profileId: studentId,
            parentNum,
          },
        });

        if (updateUserError) {
          throw new Error(updateUserError.message);
        }

        if (updatedUserData.user) {
          setCurrentUser(updatedUserData.user);
        }
      }

      return;
    }

    if (selectedRole === "Teacher") {
      const teacherId =
        metadata.profileId ??
        (await getNextNumericId(supabase, "teacher", "id"));
      const adminId = Number(teacherForm.adminId);

      const { error } = await supabase.from("teacher").upsert({
        id: teacherId,
        fname: teacherForm.firstName.trim(),
        lname: teacherForm.lastName.trim(),
        email: emailAddress,
        phone: teacherForm.phone.trim(),
        admin_id: adminId,
      });

      if (error) {
        throw new Error(error.message);
      }

      if (user) {
        const { data: updatedUserData, error: updateUserError } = await supabase.auth.updateUser({
          data: {
            role: selectedRole,
            profileId: teacherId,
          },
        });

        if (updateUserError) {
          throw new Error(updateUserError.message);
        }

        if (updatedUserData.user) {
          setCurrentUser(updatedUserData.user);
        }
      }

      return;
    }

    if (selectedRole === "Parent") {
      const parentNum =
        metadata.parentNum ?? (await getNextNumericId(supabase, "parent", "num"));

      const { error } = await supabase.from("parent").upsert({
        num: parentNum,
        parent_name: parentForm.parentName.trim(),
        relationship_with_student: parentForm.relationship.trim(),
      });

      if (error) {
        throw new Error(error.message);
      }

      if (user) {
        const { data: updatedUserData, error: updateUserError } = await supabase.auth.updateUser({
          data: {
            role: selectedRole,
            profileId: parentNum,
            parentNum,
          },
        });

        if (updateUserError) {
          throw new Error(updateUserError.message);
        }

        if (updatedUserData.user) {
          setCurrentUser(updatedUserData.user);
        }
      }
    }
  }

  async function handleAuthSubmit() {
    if (!supabase) {
      setAuthError("Supabase is not configured yet. Add the environment variables first.");
      setAuthMessage("");
      return;
    }

    if (!email.trim() || !password.trim()) {
      setAuthError("Please enter your email and password.");
      setAuthMessage("");
      return;
    }

    setAuthLoading(true);
    setAuthError("");
    setAuthMessage("");

    if (authMode === "signUp") {
      const profileValidationError = validateProfileForm(role);
      if (profileValidationError) {
        setAuthError(profileValidationError);
        setAuthLoading(false);
        return;
      }

      let nextProfileId: number | undefined;
      let nextParentNum: number | undefined;

      if (role === "Student") {
        nextProfileId = await getNextNumericId(supabase, "student", "id");
        nextParentNum = await getNextNumericId(supabase, "parent", "num");
      } else if (role === "Teacher") {
        nextProfileId = await getNextNumericId(supabase, "teacher", "id");
      } else if (role === "Parent") {
        nextProfileId = await getNextNumericId(supabase, "parent", "num");
        nextParentNum = nextProfileId;
      }

      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: {
            role,
            profileId: nextProfileId,
            parentNum: nextParentNum,
          },
        },
      });

      if (error) {
        setAuthError(error.message);
        setAuthLoading(false);
        return;
      }

      if (data.session?.user) {
        setCurrentUser(data.session.user);
      }

      try {
        await saveProfileRecord(data.session?.user ?? null, role);
        router.refresh();
        const signedUpRole = normalizeRole(data.user?.user_metadata?.role) ?? role;
        setRole(signedUpRole);
        if (data.session?.user) {
          setLoggedIn(true);
          setAuthMessage("");
        } else {
          setAuthMessage(
            "Account created and profile saved. Check your email for the confirmation link, then sign in.",
          );
        }
        resetRoleForms();
      } catch (profileError) {
        const message =
          profileError instanceof Error
            ? profileError.message
            : "Account created, but the profile record could not be saved.";
        setAuthError(message);
      }

      setAuthLoading(false);
      return;
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });

    if (error) {
      setAuthError(error.message);
      setAuthLoading(false);
      return;
    }

    setCurrentUser(data.user ?? null);
    const signedInRole = normalizeRole(data.user?.user_metadata?.role);
    if (signedInRole) {
      setRole(signedInRole);
    }
    setLoggedIn(Boolean(data.user));
    setAuthLoading(false);
  }

  async function handleCompleteProfile() {
    const validationError = validateProfileForm(activeRole);
    if (validationError) {
      setProfileError(validationError);
      return;
    }

    try {
      setProfileSaving(true);
      setProfileError("");
      await saveProfileRecord(currentUser, activeRole);
      router.refresh();
    } catch (error) {
      setProfileError(error instanceof Error ? error.message : "Failed to save profile.");
    } finally {
      setProfileSaving(false);
    }
  }

  async function handleSignOut() {
    if (!supabase) {
      setLoggedIn(false);
      setCurrentUser(null);
      setModal(null);
      return;
    }

    await supabase.auth.signOut();
    setLoggedIn(false);
    setCurrentUser(null);
    setAuthMode("signIn");
    setPassword("");
    setModal(null);
    setPage("dashboard");
    resetRoleForms();
  }

  return (
    <div className="min-h-screen bg-[#0a0c10] text-[#f0f2f7]">
      {!loggedIn && (
        <div className="fixed inset-0 z-[500] flex min-h-screen items-center justify-center overflow-hidden bg-[#0a0c10] px-4">
          <div className="pointer-events-none absolute inset-0 overflow-hidden">
            <div className="absolute -left-[5%] -top-[10%] h-[400px] w-[400px] rounded-full bg-[#4f8cff] opacity-[0.18] blur-[80px]" />
            <div className="absolute bottom-[-5%] right-[10%] h-[300px] w-[300px] rounded-full bg-[#a78bfa] opacity-[0.18] blur-[80px]" />
          </div>
          <div className="relative z-[1] w-full max-w-[420px] rounded-[20px] border border-white/[0.07] bg-[#11141a] px-10 py-11">
            <div className="font-display text-[1.8rem] font-extrabold tracking-[-0.5px]">
              My<span className="text-[#4f8cff]">School</span>
            </div>
            <p className="mb-8 mt-1 text-[0.84rem] text-[#6b7280]">
              School Management System · PSU
            </p>

            {authMode === "signUp" && (
              <div className="mb-6">
                <div className="mb-2 text-[0.72rem] font-semibold uppercase tracking-[0.12em] text-[#6b7280]">
                  Create Account As
                </div>
                <div className="flex gap-1.5 rounded-[10px] bg-[#181c24] p-1">
                  {(["Admin", "Teacher", "Student", "Parent"] as Role[]).map((item) => (
                    <button
                      key={item}
                      className={`flex-1 rounded-[7px] px-2 py-[7px] text-center text-[0.78rem] font-medium transition ${
                        role === item
                          ? "bg-[#11141a] text-[#f0f2f7] shadow-[0_1px_4px_rgba(0,0,0,0.3)]"
                          : "text-[#6b7280]"
                      }`}
                      onClick={() => setRole(item)}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {authMode === "signIn" && (
              <div className="mb-6 rounded-xl border border-white/[0.07] bg-[#181c24] px-4 py-3 text-[0.8rem] text-[#9ca3af]">
                Account permissions come from the role saved on that account. Signing in as a
                student will only open student pages.
              </div>
            )}

            <div className="mb-3">
              <input
                className={`${inputClassName()} bg-[#181c24]`}
                placeholder="Email address"
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
            </div>
            <div className="mb-3">
              <input
                className={`${inputClassName()} bg-[#181c24]`}
                type="password"
                placeholder="Password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
              />
            </div>
            {authMode === "signUp" && (
              <div className="mb-3 rounded-xl border border-white/[0.07] bg-[#181c24] p-4">
                <div className="mb-3 text-[0.78rem] font-semibold uppercase tracking-[0.08em] text-[#9ca3af]">
                  {roleLabels[role]} Profile
                </div>
                <RoleProfileFields
                  role={role}
                  studentForm={studentForm}
                  teacherForm={teacherForm}
                  parentForm={parentForm}
                  admins={adminsData}
                  onStudentChange={setStudentForm}
                  onTeacherChange={setTeacherForm}
                  onParentChange={setParentForm}
                />
              </div>
            )}
            {authError && <p className="mb-3 text-sm text-[#f87171]">{authError}</p>}
            {authMessage && <p className="mb-3 text-sm text-[#34d399]">{authMessage}</p>}
            <button
              className="mt-1 w-full rounded-[9px] bg-[#4f8cff] px-4 py-[11px] font-display text-[0.92rem] font-semibold tracking-[0.02em] text-white transition hover:bg-[#3b7ae8]"
              onClick={handleAuthSubmit}
              disabled={authLoading}
            >
              {authLoading
                ? authMode === "signIn"
                  ? "Signing in..."
                  : "Creating account..."
                : authMode === "signIn"
                  ? "Sign In →"
                  : "Create Account →"}
            </button>
            <div className="mt-5 text-center text-[0.92rem] text-[#6b7280]">
              {authMode === "signIn" ? "Don't have an account? " : "Already have an account? "}
              <button
                className="font-medium text-[#4f8cff] transition hover:text-[#7aa8ff]"
                onClick={() => {
                  setAuthMode((current) => (current === "signIn" ? "signUp" : "signIn"));
                  setAuthError("");
                  setAuthMessage("");
                }}
              >
                {authMode === "signIn" ? "Create one" : "Sign in"}
              </button>
            </div>
            <div className="mt-8 text-center text-[0.92rem] text-[#6b7280]">
              <span>Working on CS340? </span>
              <Link
                href="/phase-5-demo"
                className="font-medium text-[#34d399] transition hover:text-[#7ef0c8]"
              >
                Open Phase 5 Demo
              </Link>
            </div>
          </div>
        </div>
      )}

      <div className="flex min-h-screen">
        <aside className="hidden min-h-screen w-[240px] shrink-0 border-r border-white/[0.07] bg-[#11141a] md:fixed md:inset-y-0 md:left-0 md:flex md:flex-col">
          <div className="border-b border-white/[0.07] px-6 pb-6 pt-7">
            <div className="font-display text-[1.35rem] font-extrabold tracking-[-0.5px]">
              My<span className="text-[#4f8cff]">School</span>
            </div>
            <span className="mt-1.5 inline-block rounded-full bg-[rgba(79,140,255,0.1)] px-2 py-[2px] text-[0.7rem] font-medium uppercase tracking-[0.08em] text-[#4f8cff]">
              {roleLabels[activeRole]}
            </span>
          </div>

          <nav className="flex-1 overflow-y-auto px-3 py-4">
            {Object.entries(groupedSidebar).map(([section, items]) => (
              <div key={section}>
                <div className="px-3 pb-1.5 pt-3 text-[0.65rem] font-semibold uppercase tracking-[0.12em] text-[#6b7280]">
                  {section}
                </div>
                {items.map((item) => {
                  const isActive = page === item.id;
                  return (
                    <button
                      key={item.id}
                      className={`relative mb-px flex w-full items-center gap-2.5 rounded-lg px-3 py-[9px] text-left text-[0.88rem] transition ${
                        isActive
                          ? "bg-[rgba(79,140,255,0.13)] font-medium text-[#4f8cff]"
                          : "text-[#6b7280] hover:bg-[#181c24] hover:text-[#f0f2f7]"
                      }`}
                      onClick={() => setPage(item.id)}
                    >
                      {isActive && (
                        <span className="absolute inset-y-[20%] left-0 w-[3px] rounded-r bg-[#4f8cff]" />
                      )}
                      <span className={isActive ? "opacity-100" : "opacity-70"}>{item.icon}</span>
                      {pageLabel(activeRole, item.id)}
                    </button>
                  );
                })}
              </div>
            ))}
          </nav>

          <div className="border-t border-white/[0.07] p-3">
            <div className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 transition hover:bg-[#181c24]">
              <Avatar initials={currentUserInitials} gradient="from-[#4f8cff] to-[#a78bfa]" />
              <div>
                <div className="text-[0.82rem] font-medium">{currentUserName}</div>
                <div className="text-[0.72rem] text-[#6b7280]">
                  {currentUser?.email ?? "Signed in"}
                </div>
              </div>
              <button
                className="ml-auto rounded-lg border border-white/[0.07] px-2.5 py-1 text-[0.72rem] text-[#6b7280] transition hover:bg-[#11141a] hover:text-[#f0f2f7]"
                onClick={handleSignOut}
              >
                Sign out
              </button>
            </div>
          </div>
        </aside>

        <div className="flex min-h-screen flex-1 flex-col md:ml-[240px]">
          <header className="sticky top-0 z-50 border-b border-white/[0.07] bg-[#0a0c10]/95 backdrop-blur">
            <div className="flex h-[60px] items-center justify-between px-4 md:px-8">
              <div className="flex items-center gap-3">
                <div className="font-display text-[1.05rem] font-bold md:hidden">
                  My<span className="text-[#4f8cff]">School</span>
                </div>
                <span className="text-[0.82rem] text-[#6b7280]">
                  MySchool <span className="mx-1 opacity-40">›</span>
                  <span className="font-medium text-[#f0f2f7]">
                    {pageLabel(activeRole, page)}
                  </span>
                </span>
              </div>
              <div className="flex items-center gap-3">
                {loggedIn && (
                  <button
                    className="hidden rounded-lg border border-white/[0.07] bg-[#11141a] px-3 py-2 text-[0.78rem] font-medium text-[#6b7280] transition hover:bg-[#181c24] hover:text-[#f0f2f7] sm:inline-flex"
                    onClick={handleSignOut}
                  >
                    Logout
                  </button>
                )}
                <div className="hidden w-[200px] cursor-text items-center gap-2 rounded-lg border border-white/[0.07] bg-[#11141a] px-3.5 py-1.5 text-[0.82rem] text-[#6b7280] transition hover:border-white/[0.15] sm:flex">
                  <SearchIcon />
                  Search...
                </div>
                <button className="flex h-[34px] w-[34px] items-center justify-center rounded-lg border border-white/[0.07] bg-[#11141a] text-[#6b7280] transition hover:bg-[#181c24] hover:text-[#f0f2f7]">
                  <BellIcon />
                </button>
                <div className="flex h-[30px] w-[30px] items-center justify-center rounded-full bg-gradient-to-br from-[#4f8cff] to-[#a78bfa] text-[0.72rem] font-bold">
                  {currentUserInitials}
                </div>
              </div>
            </div>

            <div className="overflow-x-auto border-t border-white/[0.07] px-4 py-3 md:hidden">
              <div className="flex w-max items-center gap-2">
                {visibleSidebarItems.map((item) => (
                  <button
                    key={item.id}
                    className={`rounded-full border px-3 py-1.5 text-[0.78rem] transition ${
                      page === item.id
                        ? "border-[#4f8cff] bg-[rgba(79,140,255,0.13)] text-[#4f8cff]"
                        : "border-white/[0.07] bg-[#11141a] text-[#6b7280]"
                    }`}
                    onClick={() => setPage(item.id)}
                  >
                    {pageLabel(activeRole, item.id)}
                  </button>
                ))}
                {loggedIn && (
                  <button
                    className="rounded-full border border-white/[0.07] bg-[#11141a] px-3 py-1.5 text-[0.78rem] text-[#6b7280] transition hover:bg-[#181c24] hover:text-[#f0f2f7]"
                    onClick={handleSignOut}
                  >
                    Logout
                  </button>
                )}
              </div>
            </div>
          </header>

          <main className="flex-1 p-4 md:p-8">
            {page === "dashboard" && (
              <SectionShell
                title={`Good morning, ${currentUserName}`}
                subtitle={pageSubtitle(activeRole, page)}
              >
                {activeRole === "Admin" && (
                  <>
                    <div className="mb-7 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                      <StatCard
                        label="Total Students"
                        value={String(statsData.totalStudents)}
                        tone="blue"
                        icon={<StudentsIcon />}
                      />
                      <StatCard
                        label="Teachers"
                        value={String(statsData.totalTeachers)}
                        tone="purple"
                        icon={<TeacherIcon />}
                      />
                      <StatCard
                        label="Active Courses"
                        value={String(statsData.totalCourses)}
                        tone="green"
                        icon={<BookIcon />}
                      />
                      <StatCard
                        label="Enrollments"
                        value={String(statsData.totalEnrollments)}
                        tone="orange"
                        icon={<EnrollmentIcon />}
                      />
                    </div>

                    <div className="grid gap-5 xl:grid-cols-[1fr_340px]">
                      <DataCard>
                        <div className="flex items-center justify-between border-b border-white/[0.07] px-5 py-4">
                          <span className="font-display text-[0.95rem] font-semibold">
                            Recent Students
                          </span>
                          <button
                            className="text-[0.78rem] font-medium text-[#4f8cff] hover:underline"
                            onClick={() => setPage("students")}
                          >
                            View all
                          </button>
                        </div>
                        <Table
                          headers={["Student", "GPA", "Parent", "Status"]}
                          rows={studentsData.slice(0, 4).map((student) => (
                            <tr key={student.id} className="hover:bg-white/[0.02]">
                              <Cell>
                                <div className="flex items-center gap-2.5">
                                  <Avatar
                                    initials={student.initials}
                                    gradient={student.gradient}
                                    size="sm"
                                  />
                                  <div>
                                    <div className="font-medium">
                                      {student.firstName} {student.lastName}
                                    </div>
                                    <div className="text-[0.72rem] text-[#6b7280]">
                                      #{student.id}
                                    </div>
                                  </div>
                                </div>
                              </Cell>
                              <Cell className="text-[#6b7280]">{student.gpa.toFixed(2)}</Cell>
                              <Cell>{student.parentName}</Cell>
                              <Cell>
                                <Badge
                                  label={student.status}
                                  tone={student.status === "Active" ? "blue" : "green"}
                                />
                              </Cell>
                            </tr>
                          ))}
                        />
                      </DataCard>

                      <DataCard>
                        <div className="flex items-center justify-between border-b border-white/[0.07] px-5 py-4">
                          <span className="font-display text-[0.95rem] font-semibold">
                            Courses
                          </span>
                          <button
                            className="text-[0.78rem] font-medium text-[#4f8cff] hover:underline"
                            onClick={() => setPage("courses")}
                          >
                            View all
                          </button>
                        </div>
                        <div className="py-2">
                          {coursesData.map((course, index) => (
                            <div
                              key={course.id}
                              className="flex items-center gap-3 px-5 py-2.5 transition hover:bg-white/[0.02]"
                            >
                              <div
                                className="h-2 w-2 rounded-full"
                                style={{
                                  backgroundColor: [
                                    "#4f8cff",
                                    "#a78bfa",
                                    "#34d399",
                                    "#fb923c",
                                    "#f87171",
                                  ][index % 5],
                                }}
                              />
                              <div className="flex-1">
                                <div className="text-[0.84rem] font-medium">{course.name}</div>
                                <div className="mt-0.5 text-[0.74rem] text-[#6b7280]">
                                  Ms. {course.teacher}
                                </div>
                              </div>
                              <div className="font-display text-[0.95rem] font-bold text-[#6b7280]">
                                {course.enrolled}
                              </div>
                            </div>
                          ))}
                        </div>
                      </DataCard>
                    </div>
                  </>
                )}

                {activeRole === "Teacher" && activeTeacher && (
                  <>
                    <div className="mb-7 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                      <StatCard
                        label="Assigned Courses"
                        value={String(teacherCourses.length)}
                        tone="purple"
                        icon={<BookIcon />}
                      />
                      <StatCard
                        label="Students Reached"
                        value={String(teacherStudents.length)}
                        tone="blue"
                        icon={<StudentsIcon />}
                      />
                      <StatCard
                        label="Enrollments"
                        value={String(teacherEnrollmentCount)}
                        tone="green"
                        icon={<EnrollmentIcon />}
                      />
                      <StatCard
                        label="Managed By"
                        value={activeTeacher.admin.split(" ")[0] ?? activeTeacher.admin}
                        tone="orange"
                        icon={<TeacherIcon />}
                      />
                    </div>

                    <div className="grid gap-5 xl:grid-cols-[1fr_340px]">
                      <DataCard>
                        <div className="flex items-center justify-between border-b border-white/[0.07] px-5 py-4">
                          <span className="font-display text-[0.95rem] font-semibold">
                            Students In Your Courses
                          </span>
                          <button
                            className="text-[0.78rem] font-medium text-[#4f8cff] hover:underline"
                            onClick={() => setPage("students")}
                          >
                            View all
                          </button>
                        </div>
                        <Table
                          headers={["Student", "Email", "GPA", "Courses"]}
                          rows={teacherStudents.map((student) => (
                            <tr key={student.id} className="hover:bg-white/[0.02]">
                              <Cell>
                                <div className="flex items-center gap-2.5">
                                  <Avatar
                                    initials={student.initials}
                                    gradient={student.gradient}
                                    size="sm"
                                  />
                                  <div>
                                    <div className="font-medium">
                                      {student.firstName} {student.lastName}
                                    </div>
                                    <div className="text-[0.72rem] text-[#6b7280]">
                                      #{student.id}
                                    </div>
                                  </div>
                                </div>
                              </Cell>
                              <Cell className="text-[#6b7280]">{student.email}</Cell>
                              <Cell>{student.gpa.toFixed(2)}</Cell>
                              <Cell className="text-[#6b7280]">
                                {student.courses.join(", ")}
                              </Cell>
                            </tr>
                          ))}
                        />
                      </DataCard>

                      <SummaryCard title="Teacher Snapshot">
                        <div className="space-y-3 text-[0.84rem]">
                          <div>
                            <div className="text-[#6b7280]">Faculty</div>
                            <div className="mt-1 font-medium">{activeTeacher.name}</div>
                          </div>
                          <div>
                            <div className="text-[#6b7280]">Primary Course</div>
                            <div className="mt-1 font-medium">{activeTeacher.course}</div>
                          </div>
                          <div>
                            <div className="text-[#6b7280]">Email</div>
                            <div className="mt-1">{activeTeacher.email}</div>
                          </div>
                          <div>
                            <div className="text-[#6b7280]">Phone</div>
                            <div className="mt-1">{activeTeacher.phone}</div>
                          </div>
                        </div>
                      </SummaryCard>
                    </div>
                  </>
                )}

                {activeRole === "Student" && featuredStudent && (
                  <>
                    <div className="mb-7 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                      <StatCard
                        label="Current GPA"
                        value={featuredStudent.gpa.toFixed(2)}
                        tone="green"
                        icon={<StudentsIcon />}
                      />
                      <StatCard
                        label="Enrolled Courses"
                        value={String(studentCourses.length)}
                        tone="blue"
                        icon={<BookIcon />}
                      />
                      <StatCard
                        label="Parent Contact"
                        value={featuredStudent.relationship}
                        tone="purple"
                        icon={<ParentsIcon />}
                      />
                      <StatCard
                        label="Status"
                        value={featuredStudent.status}
                        tone="orange"
                        icon={<DashboardIcon />}
                      />
                    </div>

                    <div className="grid gap-5 xl:grid-cols-[1fr_340px]">
                      <SummaryCard title="Student Profile">
                        <div className="flex items-start gap-4">
                          <Avatar
                            initials={featuredStudent.initials}
                            gradient={featuredStudent.gradient}
                            size="lg"
                          />
                          <div className="space-y-3 text-[0.84rem]">
                            <div>
                              <div className="text-[#6b7280]">Student</div>
                              <div className="mt-1 font-medium">
                                {featuredStudent.firstName} {featuredStudent.middleName}.{" "}
                                {featuredStudent.lastName}
                              </div>
                            </div>
                            <div>
                              <div className="text-[#6b7280]">Email</div>
                              <div className="mt-1">{featuredStudent.email}</div>
                            </div>
                            <div>
                              <div className="text-[#6b7280]">Parent / Guardian</div>
                              <div className="mt-1">
                                {featuredStudent.parentName} ({featuredStudent.relationship})
                              </div>
                            </div>
                          </div>
                        </div>
                      </SummaryCard>

                      <SummaryCard title="My Courses">
                        <div className="space-y-3">
                          {studentCourses.map((course) => (
                            <div key={course.id} className="rounded-lg bg-[#181c24] px-3 py-3">
                              <div className="font-medium">{course.name}</div>
                              <div className="mt-1 text-[0.78rem] text-[#6b7280]">
                                Teacher: {course.teacher}
                              </div>
                            </div>
                          ))}
                        </div>
                      </SummaryCard>
                    </div>
                  </>
                )}

                {activeRole === "Parent" && activeParent && (
                  <>
                    <div className="mb-7 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                      <StatCard
                        label="Linked Students"
                        value={String(parentStudents.length)}
                        tone="blue"
                        icon={<StudentsIcon />}
                      />
                      <StatCard
                        label="Family Courses"
                        value={String(familyCourses.length)}
                        tone="green"
                        icon={<BookIcon />}
                      />
                      <StatCard
                        label="Relationship"
                        value={activeParent.relationship}
                        tone="purple"
                        icon={<ParentsIcon />}
                      />
                      <StatCard
                        label="Active Enrollments"
                        value={String(familyEnrollments.length)}
                        tone="orange"
                        icon={<EnrollmentIcon />}
                      />
                    </div>

                    <div className="grid gap-5 xl:grid-cols-[1fr_340px]">
                      <DataCard>
                        <div className="flex items-center justify-between border-b border-white/[0.07] px-5 py-4">
                          <span className="font-display text-[0.95rem] font-semibold">
                            Linked Students
                          </span>
                          <button
                            className="text-[0.78rem] font-medium text-[#4f8cff] hover:underline"
                            onClick={() => setPage("students")}
                          >
                            View all
                          </button>
                        </div>
                        <Table
                          headers={["Student", "GPA", "Status", "Courses"]}
                          rows={parentStudents.map((student) => (
                            <tr key={student.id} className="hover:bg-white/[0.02]">
                              <Cell>{studentFullName(student)}</Cell>
                              <Cell>{student.gpa.toFixed(2)}</Cell>
                              <Cell>
                                <Badge
                                  label={student.status}
                                  tone={student.status === "Active" ? "blue" : "green"}
                                />
                              </Cell>
                              <Cell className="text-[#6b7280]">
                                {student.courses.join(", ")}
                              </Cell>
                            </tr>
                          ))}
                        />
                      </DataCard>

                      <SummaryCard title="Parent Snapshot">
                        <div className="space-y-3 text-[0.84rem]">
                          <div>
                            <div className="text-[#6b7280]">Parent</div>
                            <div className="mt-1 font-medium">{activeParent.name}</div>
                          </div>
                          <div>
                            <div className="text-[#6b7280]">Relationship</div>
                            <div className="mt-1">{activeParent.relationship}</div>
                          </div>
                          <div>
                            <div className="text-[#6b7280]">Students</div>
                            <div className="mt-1">{activeParent.studentNames}</div>
                          </div>
                        </div>
                      </SummaryCard>
                    </div>
                  </>
                )}
              </SectionShell>
            )}

            {page === "students" && activeRole === "Admin" && (
              <SectionShell
                title={pageLabel(activeRole, page)}
                subtitle={pageSubtitle(activeRole, page)}
                toolbar={
                  <>
                    <div className="flex flex-wrap items-center gap-2.5">
                      <input
                        className="w-[220px] rounded-lg border border-white/[0.07] bg-[#11141a] px-3.5 py-2 text-[0.84rem] text-[#f0f2f7] outline-none placeholder:text-[#6b7280] focus:border-[#4f8cff]"
                        placeholder="Search students..."
                      />
                      <button className="rounded-lg border border-white/[0.07] bg-transparent px-4 py-2 text-[0.84rem] text-[#6b7280] transition hover:bg-[#11141a] hover:text-[#f0f2f7]">
                        Filter
                      </button>
                    </div>
                    <button
                      className="rounded-lg bg-[#4f8cff] px-4 py-2 text-[0.84rem] font-medium text-white transition hover:bg-[#3b7ae8]"
                      onClick={() => setModal("addStudent")}
                    >
                      + Add Student
                    </button>
                  </>
                }
              >
                <DataCard>
                  <Table
                    headers={["Student", "Email", "GPA", "Parent", "Actions"]}
                    rows={studentsData.map((student) => (
                      <tr key={student.id} className="hover:bg-white/[0.02]">
                        <Cell>
                          <div className="flex items-center gap-2.5">
                            <Avatar
                              initials={student.initials}
                              gradient={student.gradient}
                              size="sm"
                            />
                            <div>
                              <div className="font-medium">
                                {student.firstName} {student.lastName}
                              </div>
                              <div className="text-[0.72rem] text-[#6b7280]">#{student.id}</div>
                            </div>
                          </div>
                        </Cell>
                        <Cell className="text-[#6b7280]">{student.email}</Cell>
                        <Cell>
                          <Badge
                            label={student.gpa.toFixed(2)}
                            tone={
                              student.gpa >= 3.9
                                ? "green"
                                : student.gpa >= 3.7
                                  ? "blue"
                                  : student.gpa >= 3.5
                                    ? "green"
                                    : "orange"
                            }
                          />
                        </Cell>
                        <Cell>
                          {student.parentName} · {student.relationship}
                        </Cell>
                        <Cell>
                          <div className="flex flex-wrap items-center gap-1.5">
                            <SmallButton onClick={() => setModal("viewStudent")}>View</SmallButton>
                            <SmallButton tone="secondary">Edit</SmallButton>
                            <SmallButton tone="danger">Delete</SmallButton>
                          </div>
                        </Cell>
                      </tr>
                    ))}
                  />
                </DataCard>
              </SectionShell>
            )}

            {page === "students" && activeRole === "Teacher" && (
              <SectionShell title={pageLabel(activeRole, page)} subtitle={pageSubtitle(activeRole, page)}>
                <DataCard>
                  <Table
                    headers={["Student", "Email", "GPA", "Parent / Guardian", "Courses"]}
                    rows={teacherStudents.map((student) => (
                      <tr key={student.id} className="hover:bg-white/[0.02]">
                        <Cell>{studentFullName(student)}</Cell>
                        <Cell className="text-[#6b7280]">{student.email}</Cell>
                        <Cell>{student.gpa.toFixed(2)}</Cell>
                        <Cell>
                          {student.parentName} · {student.relationship}
                        </Cell>
                        <Cell className="text-[#6b7280]">{student.courses.join(", ")}</Cell>
                      </tr>
                    ))}
                  />
                </DataCard>
              </SectionShell>
            )}

            {page === "students" && activeRole === "Student" && featuredStudent && (
              <SectionShell title={pageLabel(activeRole, page)} subtitle={pageSubtitle(activeRole, page)}>
                <div className="grid gap-6 xl:grid-cols-[1fr_360px]">
                  <SummaryCard title="Personal Information">
                    <div className="flex items-start gap-4">
                      <Avatar
                        initials={featuredStudent.initials}
                        gradient={featuredStudent.gradient}
                        size="lg"
                      />
                      <div className="grid flex-1 gap-4 sm:grid-cols-2">
                        <InfoPair label="Student ID" value={`#${featuredStudent.id}`} />
                        <InfoPair label="Status" value={featuredStudent.status} />
                        <InfoPair label="Email" value={featuredStudent.email} />
                        <InfoPair
                          label="Parent / Guardian"
                          value={`${featuredStudent.parentName} (${featuredStudent.relationship})`}
                        />
                      </div>
                    </div>
                  </SummaryCard>

                  <SummaryCard title="Academic Summary">
                    <div className="space-y-4">
                      <InfoPair label="GPA" value={featuredStudent.gpa.toFixed(2)} />
                      <div>
                        <div className="mb-2 text-[0.78rem] font-medium uppercase tracking-[0.07em] text-[#6b7280]">
                          Courses
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {featuredStudent.courses.map((course) => (
                            <Badge key={course} label={course} tone="blue" />
                          ))}
                        </div>
                      </div>
                    </div>
                  </SummaryCard>
                </div>
              </SectionShell>
            )}

            {page === "students" && activeRole === "Parent" && (
              <SectionShell title={pageLabel(activeRole, page)} subtitle={pageSubtitle(activeRole, page)}>
                <DataCard>
                  <Table
                    headers={["Student", "Email", "GPA", "Status", "Parent Link"]}
                    rows={parentStudents.map((student) => (
                      <tr key={student.id} className="hover:bg-white/[0.02]">
                        <Cell>{studentFullName(student)}</Cell>
                        <Cell className="text-[#6b7280]">{student.email}</Cell>
                        <Cell>{student.gpa.toFixed(2)}</Cell>
                        <Cell>
                          <Badge
                            label={student.status}
                            tone={student.status === "Active" ? "blue" : "green"}
                          />
                        </Cell>
                        <Cell>{student.relationship}</Cell>
                      </tr>
                    ))}
                  />
                </DataCard>
              </SectionShell>
            )}

            {page === "teachers" && activeRole === "Admin" && (
              <SectionShell
                title={pageLabel(activeRole, page)}
                subtitle={pageSubtitle(activeRole, page)}
                toolbar={
                  <>
                    <div className="flex items-center gap-2.5">
                      <input
                        className="w-[220px] rounded-lg border border-white/[0.07] bg-[#11141a] px-3.5 py-2 text-[0.84rem] text-[#f0f2f7] outline-none placeholder:text-[#6b7280] focus:border-[#4f8cff]"
                        placeholder="Search teachers..."
                      />
                    </div>
                    <button
                      className="rounded-lg bg-[#4f8cff] px-4 py-2 text-[0.84rem] font-medium text-white transition hover:bg-[#3b7ae8]"
                      onClick={() => setModal("addTeacher")}
                    >
                      + Add Teacher
                    </button>
                  </>
                }
              >
                <DataCard>
                  <Table
                    headers={["Teacher", "Email", "Phone", "Course(s)", "Hired By", "Actions"]}
                    rows={teachersData.map((teacher, index) => (
                      <tr key={teacher.id} className="hover:bg-white/[0.02]">
                        <Cell>
                          <div className="flex items-center gap-2.5">
                            <Avatar
                              initials={teacher.initials}
                              gradient={teacher.gradient}
                              size="sm"
                            />
                            <div>
                              <div className="font-medium">{teacher.name}</div>
                              <div className="text-[0.72rem] text-[#6b7280]">#{teacher.id}</div>
                            </div>
                          </div>
                        </Cell>
                        <Cell className="text-[#6b7280]">{teacher.email}</Cell>
                        <Cell className="text-[#6b7280]">{teacher.phone}</Cell>
                        <Cell>
                          <Badge
                            label={teacher.course}
                            tone={index === 0 ? "blue" : index === 1 ? "purple" : "green"}
                          />
                        </Cell>
                        <Cell className="text-[#6b7280]">{teacher.admin}</Cell>
                        <Cell>
                          <div className="flex flex-wrap items-center gap-1.5">
                            <SmallButton tone="secondary">Edit</SmallButton>
                            <SmallButton tone="danger">Delete</SmallButton>
                          </div>
                        </Cell>
                      </tr>
                    ))}
                  />
                </DataCard>
              </SectionShell>
            )}

            {page === "teachers" && activeRole === "Teacher" && activeTeacher && (
              <SectionShell title={pageLabel(activeRole, page)} subtitle={pageSubtitle(activeRole, page)}>
                <SummaryCard title="Faculty Record">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <InfoPair label="Teacher ID" value={`#${activeTeacher.id}`} />
                    <InfoPair label="Primary Course" value={activeTeacher.course} />
                    <InfoPair label="Email" value={activeTeacher.email} />
                    <InfoPair label="Phone" value={activeTeacher.phone} />
                    <InfoPair label="Assigned Admin" value={activeTeacher.admin} />
                    <InfoPair label="Assigned Courses" value={String(teacherCourses.length)} />
                  </div>
                </SummaryCard>
              </SectionShell>
            )}

            {page === "courses" && (
              <SectionShell title={pageLabel(activeRole, page)} subtitle={pageSubtitle(activeRole, page)}>
                {activeRole === "Admin" && (
                  <DataCard>
                    <div className="flex flex-col gap-3 border-b border-white/[0.07] px-5 py-4 md:flex-row md:items-center md:justify-between">
                      <input
                        className="w-[220px] rounded-lg border border-white/[0.07] bg-[#11141a] px-3.5 py-2 text-[0.84rem] text-[#f0f2f7] outline-none placeholder:text-[#6b7280] focus:border-[#4f8cff]"
                        placeholder="Search courses..."
                      />
                      <button
                        className="rounded-lg bg-[#4f8cff] px-4 py-2 text-[0.84rem] font-medium text-white transition hover:bg-[#3b7ae8]"
                        onClick={() => setModal("addCourse")}
                      >
                        + Add Course
                      </button>
                    </div>
                    <Table
                      headers={["ID", "Course Name", "Teacher", "Managed By", "Enrolled", "Actions"]}
                      rows={coursesData.map((course) => (
                        <tr key={course.id} className="hover:bg-white/[0.02]">
                          <Cell className="text-[#6b7280]">#{course.id}</Cell>
                          <Cell>{course.name}</Cell>
                          <Cell>{course.teacher}</Cell>
                          <Cell className="text-[#6b7280]">{course.admin}</Cell>
                          <Cell>
                            <span
                              className={`inline-flex items-center rounded-full px-2 py-[2px] text-[0.72rem] font-medium ${course.accent}`}
                            >
                              {course.enrolled} students
                            </span>
                          </Cell>
                          <Cell>
                            <div className="flex flex-wrap items-center gap-1.5">
                              <SmallButton tone="secondary">Edit</SmallButton>
                              <SmallButton tone="danger">Delete</SmallButton>
                            </div>
                          </Cell>
                        </tr>
                      ))}
                    />
                  </DataCard>
                )}

                {activeRole === "Teacher" && (
                  <DataCard>
                    <Table
                      headers={["ID", "Course", "Teacher", "Managed By", "Enrollments"]}
                      rows={teacherCourses.map((course) => (
                        <tr key={course.id} className="hover:bg-white/[0.02]">
                          <Cell className="text-[#6b7280]">#{course.id}</Cell>
                          <Cell>{course.name}</Cell>
                          <Cell>{course.teacher}</Cell>
                          <Cell className="text-[#6b7280]">{course.admin}</Cell>
                          <Cell>{course.enrolled}</Cell>
                        </tr>
                      ))}
                    />
                  </DataCard>
                )}

                {activeRole === "Student" && (
                  <DataCard>
                    <Table
                      headers={["ID", "Course", "Teacher", "Enrollments"]}
                      rows={studentCourses.map((course) => (
                        <tr key={course.id} className="hover:bg-white/[0.02]">
                          <Cell className="text-[#6b7280]">#{course.id}</Cell>
                          <Cell>{course.name}</Cell>
                          <Cell>{course.teacher}</Cell>
                          <Cell>{course.enrolled}</Cell>
                        </tr>
                      ))}
                    />
                  </DataCard>
                )}

                {activeRole === "Parent" && (
                  <DataCard>
                    <Table
                      headers={["ID", "Course", "Teacher", "Linked Student(s)", "Enrollments"]}
                      rows={familyCourses.map((course) => (
                        <tr key={course.id} className="hover:bg-white/[0.02]">
                          <Cell className="text-[#6b7280]">#{course.id}</Cell>
                          <Cell>{course.name}</Cell>
                          <Cell>{course.teacher}</Cell>
                          <Cell className="text-[#6b7280]">
                            {parentStudents
                              .filter((student) => studentHasCourse(student, course))
                              .map((student) => studentFullName(student))
                              .join(", ")}
                          </Cell>
                          <Cell>{course.enrolled}</Cell>
                        </tr>
                      ))}
                    />
                  </DataCard>
                )}
              </SectionShell>
            )}

            {page === "enrollment" && activeRole === "Admin" && (
              <SectionShell title={pageLabel(activeRole, page)} subtitle={pageSubtitle(activeRole, page)}>
                <div className="grid gap-6 xl:grid-cols-2">
                  <div className="rounded-xl border border-white/[0.07] bg-[#11141a] p-6">
                    <div className="mb-5 font-display text-base font-semibold">Enroll a Student</div>
                    <div className="mb-5 grid gap-4 sm:grid-cols-2">
                      <Field label="Select Course">
                        <select className={inputClassName()}>
                          {coursesData.map((course) => (
                            <option key={course.id}>
                              {course.name} (#{course.id})
                            </option>
                          ))}
                        </select>
                      </Field>
                      <Field label="Select Student">
                        <select className={inputClassName()}>
                          {studentsData.map((student) => (
                            <option key={student.id}>
                              {student.firstName} {student.lastName} (#{student.id})
                            </option>
                          ))}
                        </select>
                      </Field>
                    </div>
                    <div className="flex justify-end">
                      <button className="rounded-lg bg-[#4f8cff] px-4 py-2 text-[0.84rem] font-medium text-white transition hover:bg-[#3b7ae8]">
                        Enroll Student →
                      </button>
                    </div>
                  </div>

                  <DataCard>
                    <div className="border-b border-white/[0.07] px-5 py-4 font-display text-[0.95rem] font-semibold">
                      Current Enrollments
                    </div>
                    <Table
                      headers={["Student", "Course", ""]}
                      rows={enrollmentsData.map((row) => (
                        <tr key={`${row.student}-${row.course}`} className="hover:bg-white/[0.02]">
                          <Cell>{row.student}</Cell>
                          <Cell>
                            <Badge label={row.course} tone={badgeToneFromEnrollment(row)} />
                          </Cell>
                          <Cell>
                            <SmallButton tone="danger">Remove</SmallButton>
                          </Cell>
                        </tr>
                      ))}
                    />
                  </DataCard>
                </div>
              </SectionShell>
            )}

            {page === "parents" && activeRole === "Admin" && (
              <SectionShell title={pageLabel(activeRole, page)} subtitle={pageSubtitle(activeRole, page)}>
                <DataCard>
                  <Table
                    headers={["#", "Parent Name", "Relationship", "Student(s)"]}
                    rows={parentsData.map((parent) => (
                      <tr key={parent.id} className="hover:bg-white/[0.02]">
                        <Cell className="text-[#6b7280]">{parent.id}</Cell>
                        <Cell>{parent.name}</Cell>
                        <Cell>
                          <Badge
                            label={parent.relationship}
                            tone={parent.relationship === "Father" ? "orange" : "purple"}
                          />
                        </Cell>
                        <Cell>{parent.studentNames}</Cell>
                      </tr>
                    ))}
                  />
                </DataCard>
              </SectionShell>
            )}

            {page === "parents" && activeRole === "Parent" && activeParent && (
              <SectionShell title={pageLabel(activeRole, page)} subtitle={pageSubtitle(activeRole, page)}>
                <SummaryCard title="Parent Record">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <InfoPair label="Parent ID" value={`#${activeParent.id}`} />
                    <InfoPair label="Name" value={activeParent.name} />
                    <InfoPair label="Relationship" value={activeParent.relationship} />
                    <InfoPair label="Linked Students" value={activeParent.studentNames} />
                  </div>
                </SummaryCard>
              </SectionShell>
            )}
          </main>
        </div>
      </div>

      {profileMissing && (
        <div className="fixed inset-0 z-[450] flex items-center justify-center bg-[#0a0c10]/90 px-4 backdrop-blur-sm">
          <div className="w-full max-w-[560px] rounded-2xl border border-white/[0.07] bg-[#11141a] p-6 shadow-2xl">
            <div className="mb-2 font-display text-[1.35rem] font-bold">
              Complete Your {roleLabels[activeRole]} Profile
            </div>
            <p className="mb-5 text-[0.9rem] text-[#9ca3af]">
              Your account is created, but you still need a matching database record before you
              can use the app.
            </p>

            <RoleProfileFields
              role={activeRole}
              studentForm={studentForm}
              teacherForm={teacherForm}
              parentForm={parentForm}
              admins={adminsData}
              onStudentChange={setStudentForm}
              onTeacherChange={setTeacherForm}
              onParentChange={setParentForm}
            />

            {profileError && <p className="mt-4 text-sm text-[#f87171]">{profileError}</p>}

            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                className="rounded-lg border border-white/[0.07] px-4 py-2 text-[0.84rem] text-[#9ca3af] transition hover:bg-[#181c24] hover:text-[#f0f2f7]"
                onClick={handleSignOut}
              >
                Sign out
              </button>
              <button
                className="rounded-lg bg-[#4f8cff] px-4 py-2 text-[0.84rem] font-medium text-white transition hover:bg-[#3b7ae8]"
                onClick={handleCompleteProfile}
                disabled={profileSaving}
              >
                {profileSaving ? "Saving..." : "Save Profile"}
              </button>
            </div>
          </div>
        </div>
      )}

      <Modal
        title="Add New Student"
        open={modal === "addStudent" && activeRole === "Admin"}
        onClose={() => setModal(null)}
        footer={
          <>
            <button
              className="rounded-lg border border-white/[0.07] px-4 py-2 text-[0.84rem] text-[#6b7280] transition hover:bg-[#11141a] hover:text-[#f0f2f7]"
              onClick={() => setModal(null)}
            >
              Cancel
            </button>
            <button className="rounded-lg bg-[#4f8cff] px-4 py-2 text-[0.84rem] font-medium text-white transition hover:bg-[#3b7ae8]">
              Save Student
            </button>
          </>
        }
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="First Name">
            <input className={inputClassName()} placeholder="e.g. Layan" />
          </Field>
          <Field label="Middle Name">
            <input className={inputClassName()} placeholder="Middle initial" />
          </Field>
        </div>
        <Field label="Last Name">
          <input className={inputClassName()} placeholder="e.g. Alotaibi" />
        </Field>
        <Field label="Email">
          <input className={inputClassName()} type="email" placeholder="student@mail.com" />
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="GPA">
            <input
              className={inputClassName()}
              type="number"
              step="0.01"
              min="0"
              max="4"
              placeholder="0.00 – 4.00"
            />
          </Field>
          <Field label="Parent">
            <select className={inputClassName()}>
              <option>Select parent...</option>
              {parentsData.map((parent) => (
                <option key={parent.id}>
                  {parent.id} · {parent.name}
                </option>
              ))}
            </select>
          </Field>
        </div>
      </Modal>

      <Modal
        title="Student Profile"
        open={modal === "viewStudent" && activeRole === "Admin" && Boolean(featuredStudent)}
        onClose={() => setModal(null)}
        footer={
          <>
            <button
              className="rounded-lg border border-white/[0.07] px-4 py-2 text-[0.84rem] text-[#6b7280] transition hover:bg-[#11141a] hover:text-[#f0f2f7]"
              onClick={() => setModal(null)}
            >
              Close
            </button>
            <button className="rounded-lg border border-white/[0.07] bg-[#181c24] px-4 py-2 text-[0.84rem] text-[#f0f2f7] transition hover:bg-[#1e2330]">
              Edit
            </button>
          </>
        }
      >
        {featuredStudent && (
          <>
            <div className="mb-6 flex items-center gap-4 border-b border-white/[0.07] pb-[18px]">
              <Avatar
                initials={featuredStudent.initials}
                gradient={featuredStudent.gradient}
                size="lg"
              />
              <div>
                <div className="font-display text-[1.1rem] font-bold">
                  {featuredStudent.firstName} {featuredStudent.middleName}.{" "}
                  {featuredStudent.lastName}
                </div>
                <div className="mt-0.5 text-[0.8rem] text-[#6b7280]">
                  Student ID: #{featuredStudent.id}
                </div>
              </div>
              <div className="ml-auto">
                <Badge label={`GPA ${featuredStudent.gpa.toFixed(2)}`} tone="green" />
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <InfoPair label="Email" value={featuredStudent.email} />
              <InfoPair
                label="Parent"
                value={`${featuredStudent.parentName} (${featuredStudent.relationship})`}
              />
            </div>
            <div className="mt-[18px]">
              <div className="mb-2 text-[0.78rem] font-medium uppercase tracking-[0.07em] text-[#6b7280]">
                Enrolled Courses
              </div>
              <div className="flex flex-wrap gap-2">
                {featuredStudent.courses.map((course) => (
                  <Badge key={course} label={course} tone="blue" />
                ))}
              </div>
            </div>
          </>
        )}
      </Modal>

      <Modal
        title="Add New Teacher"
        open={modal === "addTeacher" && activeRole === "Admin"}
        onClose={() => setModal(null)}
        footer={
          <>
            <button
              className="rounded-lg border border-white/[0.07] px-4 py-2 text-[0.84rem] text-[#6b7280] transition hover:bg-[#11141a] hover:text-[#f0f2f7]"
              onClick={() => setModal(null)}
            >
              Cancel
            </button>
            <button className="rounded-lg bg-[#4f8cff] px-4 py-2 text-[0.84rem] font-medium text-white transition hover:bg-[#3b7ae8]">
              Save Teacher
            </button>
          </>
        }
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="First Name">
            <input className={inputClassName()} placeholder="e.g. Fatimah" />
          </Field>
          <Field label="Last Name">
            <input className={inputClassName()} placeholder="e.g. Ali" />
          </Field>
        </div>
        <Field label="Email">
          <input className={inputClassName()} type="email" placeholder="teacher@mail.com" />
        </Field>
        <Field label="Phone">
          <input className={inputClassName()} type="tel" placeholder="05xxxxxxxx" />
        </Field>
        <Field label="Assigned Admin">
          <select className={inputClassName()}>
            <option>10001 · Sara Ali</option>
            <option>10002 · Noor Hassan</option>
          </select>
        </Field>
      </Modal>

      <Modal
        title="Add New Course"
        open={modal === "addCourse" && activeRole === "Admin"}
        onClose={() => setModal(null)}
        footer={
          <>
            <button
              className="rounded-lg border border-white/[0.07] px-4 py-2 text-[0.84rem] text-[#6b7280] transition hover:bg-[#11141a] hover:text-[#f0f2f7]"
              onClick={() => setModal(null)}
            >
              Cancel
            </button>
            <button className="rounded-lg bg-[#4f8cff] px-4 py-2 text-[0.84rem] font-medium text-white transition hover:bg-[#3b7ae8]">
              Save Course
            </button>
          </>
        }
      >
        <Field label="Course Name">
          <input className={inputClassName()} placeholder="e.g. Mathematics" />
        </Field>
        <Field label="Assign Teacher">
          <select className={inputClassName()}>
            {teachersData.map((teacher) => (
              <option key={teacher.id}>
                {teacher.id} · {teacher.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Managed By (Admin)">
          <select className={inputClassName()}>
            <option>10001 · Sara Ali</option>
            <option>10002 · Noor Hassan</option>
          </select>
        </Field>
      </Modal>
    </div>
  );
}

function Badge({
  label,
  tone,
}: {
  label: string;
  tone: "blue" | "green" | "purple" | "orange" | "red";
}) {
  const classes = {
    blue: "bg-[rgba(79,140,255,0.12)] text-[#4f8cff]",
    green: "bg-[rgba(52,211,153,0.12)] text-[#34d399]",
    purple: "bg-[rgba(167,139,250,0.12)] text-[#a78bfa]",
    orange: "bg-[rgba(251,146,60,0.12)] text-[#fb923c]",
    red: "bg-[rgba(248,113,113,0.12)] text-[#f87171]",
  };

  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-[2px] text-[0.72rem] font-medium ${classes[tone]}`}
    >
      {label}
    </span>
  );
}

function Avatar({
  initials,
  gradient,
  size = "md",
}: {
  initials: string;
  gradient: string;
  size?: "sm" | "md" | "lg";
}) {
  const sizes = {
    sm: "h-[30px] w-[30px] text-[0.72rem]",
    md: "h-8 w-8 text-[0.75rem]",
    lg: "h-[52px] w-[52px] text-[1.1rem]",
  };

  return (
    <div
      className={`flex items-center justify-center rounded-full bg-gradient-to-br ${gradient} font-semibold text-white ${sizes[size]}`}
    >
      {initials}
    </div>
  );
}

function Modal({
  title,
  open,
  onClose,
  children,
  footer,
}: {
  title: string;
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  footer: ReactNode;
}) {
  return (
    <div
      className={`fixed inset-0 z-[200] flex items-center justify-center bg-black/60 px-4 backdrop-blur-sm transition ${
        open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0"
      }`}
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div
        className={`max-h-[90vh] w-full max-w-[480px] overflow-y-auto rounded-2xl border border-white/[0.07] bg-[#11141a] transition ${
          open ? "translate-y-0 scale-100" : "translate-y-4 scale-[0.98]"
        }`}
      >
        <div className="flex items-center justify-between border-b border-white/[0.07] px-6 py-5">
          <span className="font-display text-[1.05rem] font-bold">{title}</span>
          <button
            className="flex h-7 w-7 items-center justify-center rounded-md border border-white/[0.07] text-base text-[#6b7280] transition hover:bg-[#181c24] hover:text-[#f0f2f7]"
            onClick={onClose}
            aria-label="Close modal"
          >
            ✕
          </button>
        </div>
        <div className="px-6 py-6">{children}</div>
        <div className="flex items-center justify-end gap-2.5 border-t border-white/[0.07] px-6 py-4">
          {footer}
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div className="mb-4">
      <label className="mb-1.5 block text-[0.78rem] font-medium uppercase tracking-[0.07em] text-[#6b7280]">
        {label}
      </label>
      {children}
    </div>
  );
}

function SectionShell({
  title,
  subtitle,
  toolbar,
  children,
}: {
  title: string;
  subtitle: string;
  toolbar?: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className="animate-fadeIn">
      <div className="mb-7">
        <div className="font-display text-[1.6rem] font-bold tracking-[-0.5px]">{title}</div>
        <div className="mt-1 text-[0.85rem] text-[#6b7280]">{subtitle}</div>
      </div>
      {toolbar && (
        <div className="mb-5 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          {toolbar}
        </div>
      )}
      {children}
    </div>
  );
}

function DataCard({ children }: { children: ReactNode }) {
  return (
    <div className="overflow-hidden rounded-xl border border-white/[0.07] bg-[#11141a]">
      {children}
    </div>
  );
}

function Table({
  headers,
  rows,
}: {
  headers: string[];
  rows: ReactNode[];
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr>
            {headers.map((header) => (
              <th
                key={header}
                className="border-b border-white/[0.07] px-5 py-3 text-left text-[0.7rem] font-semibold uppercase tracking-[0.08em] text-[#6b7280]"
              >
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>{rows}</tbody>
      </table>
    </div>
  );
}

function Cell({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <td className={`border-b border-white/[0.07] px-5 py-3 text-[0.84rem] ${className}`}>{children}</td>;
}

function SmallButton({
  children,
  tone = "ghost",
  onClick,
}: {
  children: ReactNode;
  tone?: "ghost" | "secondary" | "danger";
  onClick?: () => void;
}) {
  const styles = {
    ghost:
      "border border-white/[0.07] bg-transparent text-[#6b7280] hover:bg-[#11141a] hover:text-[#f0f2f7]",
    secondary:
      "border border-white/[0.07] bg-[#181c24] text-[#f0f2f7] hover:bg-[#1e2330]",
    danger:
      "border border-[rgba(248,113,113,0.2)] bg-[rgba(248,113,113,0.12)] text-[#f87171] hover:bg-[rgba(248,113,113,0.2)]",
  };

  return (
    <button
      className={`rounded-lg px-2.5 py-[5px] text-[0.78rem] transition ${styles[tone]}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
}

function InfoPair({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div>
      <div className="mb-2 text-[0.78rem] font-medium uppercase tracking-[0.07em] text-[#6b7280]">
        {label}
      </div>
      <div className="text-[0.85rem]">{value}</div>
    </div>
  );
}

function RoleProfileFields({
  role,
  studentForm,
  teacherForm,
  parentForm,
  admins,
  onStudentChange,
  onTeacherChange,
  onParentChange,
}: {
  role: Role;
  studentForm: StudentFormState;
  teacherForm: TeacherFormState;
  parentForm: ParentFormState;
  admins: AdminProfile[];
  onStudentChange: React.Dispatch<React.SetStateAction<StudentFormState>>;
  onTeacherChange: React.Dispatch<React.SetStateAction<TeacherFormState>>;
  onParentChange: React.Dispatch<React.SetStateAction<ParentFormState>>;
}) {
  if (role === "Student") {
    return (
      <div className="grid gap-3 sm:grid-cols-2">
        <CompactField label="First Name">
          <SmallInput
            value={studentForm.firstName}
            onChange={(value) => onStudentChange((current) => ({ ...current, firstName: value }))}
            placeholder="Layan"
          />
        </CompactField>
        <CompactField label="Middle Name">
          <SmallInput
            value={studentForm.middleName}
            onChange={(value) => onStudentChange((current) => ({ ...current, middleName: value }))}
            placeholder="A"
          />
        </CompactField>
        <CompactField label="Last Name">
          <SmallInput
            value={studentForm.lastName}
            onChange={(value) => onStudentChange((current) => ({ ...current, lastName: value }))}
            placeholder="Alotaibi"
          />
        </CompactField>
        <CompactField label="GPA">
          <SmallInput
            value={studentForm.gpa}
            onChange={(value) => onStudentChange((current) => ({ ...current, gpa: value }))}
            placeholder="3.50"
            type="number"
          />
        </CompactField>
        <CompactField label="Parent Name">
          <SmallInput
            value={studentForm.parentName}
            onChange={(value) => onStudentChange((current) => ({ ...current, parentName: value }))}
            placeholder="Saud Alotaibi"
          />
        </CompactField>
        <CompactField label="Relationship">
          <SmallInput
            value={studentForm.relationship}
            onChange={(value) =>
              onStudentChange((current) => ({ ...current, relationship: value }))
            }
            placeholder="Father"
          />
        </CompactField>
      </div>
    );
  }

  if (role === "Teacher") {
    return (
      <div className="grid gap-3 sm:grid-cols-2">
        <CompactField label="First Name">
          <SmallInput
            value={teacherForm.firstName}
            onChange={(value) => onTeacherChange((current) => ({ ...current, firstName: value }))}
            placeholder="Fatimah"
          />
        </CompactField>
        <CompactField label="Last Name">
          <SmallInput
            value={teacherForm.lastName}
            onChange={(value) => onTeacherChange((current) => ({ ...current, lastName: value }))}
            placeholder="Ali"
          />
        </CompactField>
        <CompactField label="Phone">
          <SmallInput
            value={teacherForm.phone}
            onChange={(value) => onTeacherChange((current) => ({ ...current, phone: value }))}
            placeholder="0501111111"
          />
        </CompactField>
        <CompactField label="Assigned Admin">
          <select
            className={`${inputClassName()} bg-[#0f1319] text-[0.84rem]`}
            value={teacherForm.adminId}
            onChange={(event) =>
              onTeacherChange((current) => ({ ...current, adminId: event.target.value }))
            }
          >
            <option value="">Select admin...</option>
            {admins.map((admin) => (
              <option key={admin.id} value={admin.id}>
                {admin.id} · {admin.name}
              </option>
            ))}
          </select>
        </CompactField>
      </div>
    );
  }

  if (role === "Parent") {
    return (
      <div className="grid gap-3 sm:grid-cols-2">
        <CompactField label="Parent Name">
          <SmallInput
            value={parentForm.parentName}
            onChange={(value) => onParentChange((current) => ({ ...current, parentName: value }))}
            placeholder="Saud Alotaibi"
          />
        </CompactField>
        <CompactField label="Relationship">
          <SmallInput
            value={parentForm.relationship}
            onChange={(value) =>
              onParentChange((current) => ({ ...current, relationship: value }))
            }
            placeholder="Father"
          />
        </CompactField>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-white/[0.07] bg-[#181c24] px-3 py-3 text-[0.84rem] text-[#9ca3af]">
      Admin accounts use the management dashboard and do not require a separate profile form here.
    </div>
  );
}

function CompactField({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div>
      <div className="mb-1.5 text-[0.72rem] font-medium uppercase tracking-[0.08em] text-[#6b7280]">
        {label}
      </div>
      {children}
    </div>
  );
}

function SmallInput({
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  type?: string;
}) {
  return (
    <input
      className={`${inputClassName()} bg-[#0f1319] text-[0.84rem]`}
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder}
      type={type}
    />
  );
}
