-- MySchool Phase 5 query pack for MySQL
-- These queries follow the schema from Phases 3 and 4.

USE myschool;

-- 1. View all students
SELECT ID, Fname, Mname, Lname, Email, GPA
FROM STUDENT;

-- 2. View all teachers
SELECT ID, Fname, Lname, Email, Phone
FROM TEACHER;

-- 3. View all courses
SELECT ID, Name, Teacher_ID, Admin_ID
FROM COURSE;

-- 4. Insert a new student
INSERT INTO STUDENT (ID, Fname, Mname, Lname, Email, GPA, Parent_Num)
VALUES (22211, 'Amira', 'K', 'Alqahtani', 'amira11@mail.com', 3.75, 50001);

-- 5. Update a student's GPA
UPDATE STUDENT
SET GPA = 3.95
WHERE ID = 22203;

-- 6. Show students with their parent details
SELECT s.ID,
       s.Fname,
       s.Lname,
       p.Parent_Name,
       p.Relationship_with_student
FROM STUDENT AS s
JOIN PARENT AS p
  ON s.Parent_Num = p.Num;

-- 7. Show each student with enrolled courses
SELECT s.ID AS Student_ID,
       CONCAT(s.Fname, ' ', s.Lname) AS Student_Name,
       c.ID AS Course_ID,
       c.Name AS Course_Name
FROM STUDENT AS s
JOIN ENROLLMENT AS e
  ON s.ID = e.Student_ID
JOIN COURSE AS c
  ON e.Course_ID = c.ID
ORDER BY s.ID, c.ID;

-- 8. Count how many students are enrolled in each course
SELECT c.ID,
       c.Name,
       COUNT(e.Student_ID) AS Enrolled_Students
FROM COURSE AS c
LEFT JOIN ENROLLMENT AS e
  ON c.ID = e.Course_ID
GROUP BY c.ID, c.Name
ORDER BY Enrolled_Students DESC, c.ID;

-- 9. Show teachers with the courses they teach
SELECT t.ID AS Teacher_ID,
       CONCAT(t.Fname, ' ', t.Lname) AS Teacher_Name,
       c.ID AS Course_ID,
       c.Name AS Course_Name
FROM TEACHER AS t
JOIN COURSE AS c
  ON t.ID = c.Teacher_ID
ORDER BY t.ID, c.ID;

-- 10. Show students with GPA above the overall average
SELECT ID,
       Fname,
       Lname,
       GPA
FROM STUDENT
WHERE GPA > (
  SELECT AVG(GPA)
  FROM STUDENT
)
ORDER BY GPA DESC;
