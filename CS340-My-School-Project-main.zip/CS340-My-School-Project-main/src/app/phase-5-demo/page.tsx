import { Phase5DemoApp } from "@/components/phase5-demo-app";

export default function Phase5DemoPage() {
  return <Phase5DemoApp />;
}
