import { NextResponse } from "next/server";

import { runMutation, runSelectQuery } from "@/lib/mysql";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await runSelectQuery(
      `SELECT ID, Fname, Mname, Lname, Email, GPA, Parent_Num
       FROM STUDENT
       ORDER BY ID DESC`,
    );

    return NextResponse.json({ rows });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to load students.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, string>;

    await runMutation(
      `INSERT INTO STUDENT (ID, Fname, Mname, Lname, Email, GPA, Parent_Num)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        Number(body.id),
        body.fname,
        body.mname || null,
        body.lname,
        body.email,
        Number(body.gpa),
        Number(body.parentNum),
      ],
    );

    const rows = await runSelectQuery(
      `SELECT ID, Fname, Mname, Lname, Email, GPA, Parent_Num
       FROM STUDENT
       ORDER BY ID DESC`,
    );

    return NextResponse.json({ message: "Student added successfully.", rows });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to add student.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const studentId = Number(searchParams.get("id"));

    if (!studentId) {
      return NextResponse.json({ error: "Student ID is required." }, { status: 400 });
    }

    const result = await runMutation(`DELETE FROM STUDENT WHERE ID = ?`, [studentId]);
    const rows = await runSelectQuery(
      `SELECT ID, Fname, Mname, Lname, Email, GPA, Parent_Num
       FROM STUDENT
       ORDER BY ID DESC`,
    );

    return NextResponse.json({
      message:
        result.affectedRows > 0
          ? "Student deleted successfully."
          : "No student was deleted. Check the ID and try again.",
      rows,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to delete student.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
