import { NextResponse } from "next/server";

import { runMutation, runSelectQuery } from "@/lib/mysql";

export const dynamic = "force-dynamic";

async function loadEnrollments() {
  return runSelectQuery(
    `SELECT e.Student_ID,
            CONCAT(s.Fname, ' ', s.Lname) AS Student_Name,
            e.Course_ID,
            c.Name AS Course_Name
     FROM ENROLLMENT e
     JOIN STUDENT s ON s.ID = e.Student_ID
     JOIN COURSE c ON c.ID = e.Course_ID
     ORDER BY e.Student_ID DESC, e.Course_ID DESC`,
  );
}

export async function GET() {
  try {
    const rows = await loadEnrollments();
    return NextResponse.json({ rows });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to load enrollments.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, string>;

    await runMutation(`INSERT INTO ENROLLMENT (Student_ID, Course_ID) VALUES (?, ?)`, [
      Number(body.studentId),
      Number(body.courseId),
    ]);

    const rows = await loadEnrollments();
    return NextResponse.json({ message: "Enrollment added successfully.", rows });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to add enrollment.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const studentId = Number(searchParams.get("studentId"));
    const courseId = Number(searchParams.get("courseId"));

    if (!studentId || !courseId) {
      return NextResponse.json(
        { error: "Student ID and course ID are required." },
        { status: 400 },
      );
    }

    const result = await runMutation(
      `DELETE FROM ENROLLMENT WHERE Student_ID = ? AND Course_ID = ?`,
      [studentId, courseId],
    );

    const rows = await loadEnrollments();
    return NextResponse.json({
      message:
        result.affectedRows > 0
          ? "Enrollment deleted successfully."
          : "No enrollment was deleted. Check the keys and try again.",
      rows,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to delete enrollment.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
