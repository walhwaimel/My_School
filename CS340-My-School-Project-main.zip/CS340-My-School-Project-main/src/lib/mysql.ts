import mysql, {
  type Pool,
  type ResultSetHeader,
  type RowDataPacket,
} from "mysql2/promise";

let pool: Pool | undefined;

type MysqlValue = string | number | bigint | boolean | Date | null | Buffer | Uint8Array;

function getConnectionUri() {
  return (
    process.env.PHASE5_DATABASE_URL ||
    process.env.MYSQL_PUBLIC_URL ||
    process.env.MYSQL_URL ||
    process.env.DATABASE_URL
  );
}

function createPool() {
  const uri = getConnectionUri();

  if (uri) {
    return mysql.createPool({
      uri,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
    });
  }

  const host = process.env.MYSQL_HOST || process.env.MYSQLHOST;
  const port = Number(process.env.MYSQL_PORT || process.env.MYSQLPORT || 3306);
  const user = process.env.MYSQL_USER || process.env.MYSQLUSER;
  const password = process.env.MYSQL_PASSWORD || process.env.MYSQLPASSWORD;
  const database =
    process.env.MYSQL_DATABASE ||
    process.env.MYSQLDATABASE ||
    process.env.PHASE5_DATABASE ||
    "myschool_phase5";

  if (!host || !user || !password) {
    throw new Error(
      "Phase 5 MySQL is not configured. Set PHASE5_DATABASE_URL or MYSQL_HOST/MYSQL_USER/MYSQL_PASSWORD/MYSQL_DATABASE.",
    );
  }

  return mysql.createPool({
    host,
    port,
    user,
    password,
    database,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  });
}

export function getMysqlPool() {
  if (!pool) {
    pool = createPool();
  }

  return pool;
}

export async function runSelectQuery(sql: string, values: MysqlValue[] = []) {
  const [rows] = await getMysqlPool().query<RowDataPacket[]>(sql, values);
  return rows.map((row) => ({ ...row }));
}

export async function runMutation(sql: string, values: MysqlValue[] = []) {
  const [result] = await getMysqlPool().execute<ResultSetHeader>(sql, values);
  return result;
}
