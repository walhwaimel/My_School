import { MySchoolApp } from "@/components/myschool-app";
import { getPrototypeData } from "@/lib/supabase/prototype";

export default async function Home() {
  const data = await getPrototypeData();

  return <MySchoolApp initialData={data ?? undefined} />;
}
