export type QueryCategory = "Basic" | "Advanced";

export type QueryField = {
  name: string;
  label: string;
  placeholder: string;
  type?: "text" | "number" | "email";
  required?: boolean;
};

export type QueryDefinition = {
  id: string;
  category: QueryCategory;
  title: string;
  summary: string;
  sql: string;
  mode: "select" | "insert" | "delete";
  fields?: QueryField[];
};

export const phase5Queries: QueryDefinition[] = [
  {
    id: "q1",
    category: "Basic",
    title: "View All Students",
    summary: "Lists the core student records stored in the MySQL phase 5 database.",
    mode: "select",
    sql: `SELECT ID, Fname, Mname, Lname, Email, GPA, Parent_Num
FROM STUDENT
ORDER BY ID;`,
  },
  {
    id: "q2",
    category: "Basic",
    title: "View All Teachers",
    summary: "Shows the available teacher records for staff management.",
    mode: "select",
    sql: `SELECT ID, Fname, Lname, Email, Phone, Admin_ID
FROM TEACHER
ORDER BY ID;`,
  },
  {
    id: "q3",
    category: "Basic",
    title: "View All Courses",
    summary: "Displays the course catalog maintained by the admin side of the system.",
    mode: "select",
    sql: `SELECT ID, Name, Teacher_ID, Admin_ID
FROM COURSE
ORDER BY ID;`,
  },
  {
    id: "q4",
    category: "Basic",
    title: "Insert A New Student",
    summary: "Adds a student directly into the Railway MySQL database from the demo UI.",
    mode: "insert",
    sql: `INSERT INTO STUDENT (ID, Fname, Mname, Lname, Email, GPA, Parent_Num)
VALUES (?, ?, ?, ?, ?, ?, ?);`,
    fields: [
      { name: "id", label: "Student ID", placeholder: "22211", type: "number", required: true },
      { name: "fname", label: "First Name", placeholder: "Amira", required: true },
      { name: "mname", label: "Middle Name", placeholder: "K" },
      { name: "lname", label: "Last Name", placeholder: "Alqahtani", required: true },
      { name: "email", label: "Email", placeholder: "amira11@mail.com", type: "email", required: true },
      { name: "gpa", label: "GPA", placeholder: "3.75", type: "number", required: true },
      { name: "parentNum", label: "Parent Number", placeholder: "50001", type: "number", required: true },
    ],
  },
  {
    id: "q5",
    category: "Basic",
    title: "Delete A Student",
    summary: "Deletes a student record by ID so the demo can show a true delete operation.",
    mode: "delete",
    sql: `DELETE FROM STUDENT
WHERE ID = ?;`,
    fields: [
      { name: "id", label: "Student ID", placeholder: "22211", type: "number", required: true },
    ],
  },
  {
    id: "q6",
    category: "Advanced",
    title: "Students With Parent Details",
    summary: "Uses a join to connect student records with parent data.",
    mode: "select",
    sql: `SELECT s.ID,
       s.Fname,
       s.Lname,
       p.Parent_Name,
       p.Relationship_with_student
FROM STUDENT s
JOIN PARENT p ON s.Parent_Num = p.Num
ORDER BY s.ID;`,
  },
  {
    id: "q7",
    category: "Advanced",
    title: "Students And Their Enrolled Courses",
    summary: "Uses a multi-table join to display course registration data.",
    mode: "select",
    sql: `SELECT s.ID AS Student_ID,
       CONCAT(s.Fname, ' ', s.Lname) AS Student_Name,
       c.ID AS Course_ID,
       c.Name AS Course_Name
FROM STUDENT s
JOIN ENROLLMENT e ON s.ID = e.Student_ID
JOIN COURSE c ON e.Course_ID = c.ID
ORDER BY s.ID, c.ID;`,
  },
  {
    id: "q8",
    category: "Advanced",
    title: "Student Count Per Course",
    summary: "Uses aggregation to count enrollments in each course.",
    mode: "select",
    sql: `SELECT c.ID,
       c.Name,
       COUNT(e.Student_ID) AS Enrolled_Students
FROM COURSE c
LEFT JOIN ENROLLMENT e ON c.ID = e.Course_ID
GROUP BY c.ID, c.Name
ORDER BY Enrolled_Students DESC, c.ID;`,
  },
  {
    id: "q9",
    category: "Advanced",
    title: "Teachers With Their Courses",
    summary: "Uses a join to show which teacher is assigned to which course.",
    mode: "select",
    sql: `SELECT t.ID AS Teacher_ID,
       CONCAT(t.Fname, ' ', t.Lname) AS Teacher_Name,
       c.ID AS Course_ID,
       c.Name AS Course_Name
FROM TEACHER t
JOIN COURSE c ON t.ID = c.Teacher_ID
ORDER BY t.ID, c.ID;`,
  },
  {
    id: "q10",
    category: "Advanced",
    title: "Students Above Average GPA",
    summary: "Uses a subquery to compare individual GPA values to the average.",
    mode: "select",
    sql: `SELECT ID, Fname, Lname, GPA
FROM STUDENT
WHERE GPA > (
  SELECT AVG(GPA) FROM STUDENT
)
ORDER BY GPA DESC, ID;`,
  },
];

export function getPhase5Query(queryId: string) {
  return phase5Queries.find((query) => query.id === queryId);
}
