# MySchool

MySchool is a `CS340` full-stack school management project with two clearly separated parts:

- Prototype app: `Supabase + Vercel`
- Phase 5 query demo: `MySQL + Vercel`

That split matches your intended submission structure:
- the main product prototype uses `Supabase` as the hosted relational database
- the query-specific Phase 5 part stays separate and is centered on `MySQL`

## Routes

- [/](http://localhost:3000): main MySchool prototype
- [/phase-5-demo](http://localhost:3000/phase-5-demo): separate Phase 5 query demo entry

The login screen in the main prototype includes a direct `Open Phase 5 Demo` link so the separation is visible, similar to your reference example.

## Repo Structure

- [src/app/page.tsx](/Users/shougalomran/Desktop/CS340-My-School-Project/src/app/page.tsx): main prototype route
- [src/components/myschool-app.tsx](/Users/shougalomran/Desktop/CS340-My-School-Project/src/components/myschool-app.tsx): main UI shell and prototype pages
- [src/lib/supabase/prototype.ts](/Users/shougalomran/Desktop/CS340-My-School-Project/src/lib/supabase/prototype.ts): Supabase data loader for the prototype
- [src/app/phase-5-demo/page.tsx](/Users/shougalomran/Desktop/CS340-My-School-Project/src/app/phase-5-demo/page.tsx): separate MySQL Phase 5 demo route
- [supabase/setup.sql](/Users/shougalomran/Desktop/CS340-My-School-Project/supabase/setup.sql): full Supabase setup and seed data
- [mysql/phase5-queries.sql](/Users/shougalomran/Desktop/CS340-My-School-Project/mysql/phase5-queries.sql): MySQL Phase 5 query file
- [.env.example](/Users/shougalomran/Desktop/CS340-My-School-Project/.env.example): environment variable template

## Supabase Setup

1. Create a new Supabase project.
2. Open the `SQL Editor`.
3. Run [supabase/setup.sql](/Users/shougalomran/Desktop/CS340-My-School-Project/supabase/setup.sql).
4. Copy `.env.example` to `.env.local`.
5. Fill in:

```env
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
```

## Run Locally

```bash
npm install
npm run dev
```

## Deploy To Vercel

### Main Prototype

Deploy the repo to `Vercel` and add:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

### Phase 5 Demo

The Phase 5 demo is already part of the same repo as a separate route. It is intentionally isolated from the Supabase prototype and points to the MySQL deliverable logic in [mysql/phase5-queries.sql](/Users/shougalomran/Desktop/CS340-My-School-Project/mysql/phase5-queries.sql).

## Notes

- The prototype will use Supabase data when the environment variables are set.
- If Supabase is not configured yet, the UI falls back to local sample data so the interface still renders during development.
- If you want the Phase 5 demo to become a fully separate Vercel project later, we can split it into its own app folder next.
