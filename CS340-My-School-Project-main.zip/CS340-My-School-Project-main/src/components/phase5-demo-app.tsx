"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";

import { getPhase5Query } from "@/lib/phase5/query-definitions";

type DemoTab = "students" | "enrollments" | "queries";

type StudentRow = {
  ID: number;
  Fname: string;
  Mname: string | null;
  Lname: string;
  Email: string;
  GPA: number;
  Parent_Num: number;
};

type EnrollmentRow = {
  Student_ID: number;
  Student_Name: string;
  Course_ID: number;
  Course_Name: string;
};

type QueryResponse = {
  columns?: string[];
  rows?: Record<string, unknown>[] | Array<Record<string, unknown> | unknown[]>;
  message?: string;
  error?: string;
};

const emptyStudentForm = {
  id: "",
  fname: "",
  mname: "",
  lname: "",
  email: "",
  gpa: "",
  parentNum: "",
};

const emptyEnrollmentForm = {
  studentId: "",
  courseId: "",
};

function TabButton({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-2xl px-6 py-4 text-base font-semibold transition ${
        active
          ? "bg-[linear-gradient(135deg,#111827,#0f2b46)] text-white shadow-[0_10px_25px_rgba(15,23,42,0.18)]"
          : "text-[#475569] hover:bg-[#f3f6fb]"
      }`}
    >
      {label}
    </button>
  );
}

export function Phase5DemoApp() {
  const [activeTab, setActiveTab] = useState<DemoTab>("students");
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [enrollments, setEnrollments] = useState<EnrollmentRow[]>([]);
  const [studentForm, setStudentForm] = useState(emptyStudentForm);
  const [enrollmentForm, setEnrollmentForm] = useState(emptyEnrollmentForm);
  const [studentMessage, setStudentMessage] = useState("");
  const [enrollmentMessage, setEnrollmentMessage] = useState("");
  const [queryMessage, setQueryMessage] = useState("");
  const [queryIdInput, setQueryIdInput] = useState("");
  const [selectedQueryId, setSelectedQueryId] = useState<string | null>(null);
  const [queryResult, setQueryResult] = useState<QueryResponse | null>(null);
  const [loadingStudents, setLoadingStudents] = useState(false);
  const [loadingEnrollments, setLoadingEnrollments] = useState(false);
  const [loadingQuery, setLoadingQuery] = useState(false);

  const selectedQuery = selectedQueryId ? getPhase5Query(selectedQueryId) ?? null : null;

  const queryRows = useMemo(() => queryResult?.rows ?? [], [queryResult]);
  const queryColumns = queryResult?.columns ?? [];

  async function loadStudents() {
    setLoadingStudents(true);

    try {
      const response = await fetch("/api/phase5/students", { cache: "no-store" });
      const data = (await response.json()) as { rows?: StudentRow[]; error?: string };

      if (data.error) {
        setStudentMessage(data.error);
        return;
      }

      setStudents(data.rows ?? []);
    } finally {
      setLoadingStudents(false);
    }
  }

  async function loadEnrollments() {
    setLoadingEnrollments(true);

    try {
      const response = await fetch("/api/phase5/enrollments", { cache: "no-store" });
      const data = (await response.json()) as { rows?: EnrollmentRow[]; error?: string };

      if (data.error) {
        setEnrollmentMessage(data.error);
        return;
      }

      setEnrollments(data.rows ?? []);
    } finally {
      setLoadingEnrollments(false);
    }
  }

  const runQuery = useCallback(async (nextQueryId?: string) => {
    const rawValue = (nextQueryId ?? queryIdInput).trim().toLowerCase();
    const queryId = rawValue.startsWith("q") ? rawValue : `q${rawValue}`;
    const query = getPhase5Query(queryId);

    if (!query) {
      setSelectedQueryId(null);
      setQueryResult(null);
      setQueryMessage("That query number does not exist. Enter a number from 1 to 10.");
      return;
    }

    setSelectedQueryId(queryId);
    setQueryIdInput(queryId.replace("q", ""));
    setLoadingQuery(true);

    try {
      const response = await fetch("/api/phase5", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ queryId }),
      });

      const data = (await response.json()) as QueryResponse;
      setQueryResult(data);
      setQueryMessage(data.error ?? data.message ?? "");
    } finally {
      setLoadingQuery(false);
    }
  }, [queryIdInput]);

  useEffect(() => {
    void loadStudents();
    void loadEnrollments();
  }, []);

  const queryPreviewJson = useMemo(() => {
    if (queryRows.length === 0) {
      return "[]";
    }

    return JSON.stringify(queryRows, null, 2);
  }, [queryRows]);

  async function handleAddStudent(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStudentMessage("Saving student...");

    const response = await fetch("/api/phase5/students", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(studentForm),
    });

    const data = (await response.json()) as { rows?: StudentRow[]; message?: string; error?: string };
    setStudentMessage(data.error ?? data.message ?? "");

    if (!data.error) {
      setStudents(data.rows ?? []);
      setStudentForm(emptyStudentForm);
      if (selectedQueryId === "q1") {
        void runQuery("q1");
      }
    }
  }

  async function handleDeleteStudent(id: number) {
    setStudentMessage(`Deleting student ${id}...`);

    const response = await fetch(`/api/phase5/students?id=${id}`, {
      method: "DELETE",
    });

    const data = (await response.json()) as { rows?: StudentRow[]; message?: string; error?: string };
    setStudentMessage(data.error ?? data.message ?? "");

    if (!data.error) {
      setStudents(data.rows ?? []);
      if (selectedQueryId === "q1") {
        void runQuery("q1");
      }
    }
  }

  async function handleAddEnrollment(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setEnrollmentMessage("Saving enrollment...");

    const response = await fetch("/api/phase5/enrollments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(enrollmentForm),
    });

    const data = (await response.json()) as {
      rows?: EnrollmentRow[];
      message?: string;
      error?: string;
    };

    setEnrollmentMessage(data.error ?? data.message ?? "");

    if (!data.error) {
      setEnrollments(data.rows ?? []);
      setEnrollmentForm(emptyEnrollmentForm);
      if (selectedQueryId === "q7") {
        void runQuery("q7");
      }
    }
  }

  async function handleDeleteEnrollment(studentId: number, courseId: number) {
    setEnrollmentMessage(`Deleting enrollment ${studentId}/${courseId}...`);

    const response = await fetch(
      `/api/phase5/enrollments?studentId=${studentId}&courseId=${courseId}`,
      { method: "DELETE" },
    );

    const data = (await response.json()) as {
      rows?: EnrollmentRow[];
      message?: string;
      error?: string;
    };

    setEnrollmentMessage(data.error ?? data.message ?? "");

    if (!data.error) {
      setEnrollments(data.rows ?? []);
      if (selectedQueryId === "q7") {
        void runQuery("q7");
      }
    }
  }

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_left,_rgba(56,189,248,0.10),_transparent_24%),radial-gradient(circle_at_bottom_right,_rgba(16,185,129,0.10),_transparent_28%),linear-gradient(180deg,_#f8fbff_0%,_#eef5ff_48%,_#f9fcff_100%)] px-4 py-8 text-[#0f172a] md:px-8 md:py-10">
      <div className="mx-auto max-w-[1320px]">
        <div className="mb-6 flex justify-end">
          <Link
            href="/"
            className="rounded-2xl border border-[#dbe4f0] bg-white px-6 py-3 text-sm font-semibold text-[#334155] shadow-[0_12px_30px_rgba(148,163,184,0.12)] transition hover:-translate-y-0.5 hover:bg-[#fbfdff]"
          >
            Back To Prototype
          </Link>
        </div>

        <div className="mb-10 inline-flex rounded-[26px] border border-[#e3ebf5] bg-white p-2 shadow-[0_18px_40px_rgba(148,163,184,0.10)]">
          <TabButton
            active={activeTab === "students"}
            label="Students"
            onClick={() => setActiveTab("students")}
          />
          <TabButton
            active={activeTab === "enrollments"}
            label="Enrollments"
            onClick={() => setActiveTab("enrollments")}
          />
          <TabButton
            active={activeTab === "queries"}
            label="Queries"
            onClick={() => setActiveTab("queries")}
          />
        </div>

        {activeTab === "students" ? (
          <section className="rounded-[30px] border border-[#e3ebf5] bg-white p-8 shadow-[0_24px_60px_rgba(148,163,184,0.10)]">
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#2563eb]">
              Phase 5 CRUD
            </p>
            <h1 className="mt-3 font-display text-5xl font-bold tracking-[-0.04em] text-[#0f172a]">
              Students
            </h1>
            <p className="mt-4 max-w-3xl text-lg text-[#64748b]">
              Add student rows to the Phase 5 MySQL database and verify that the table refreshes
              from Railway after every insert or delete.
            </p>

            <form
              onSubmit={handleAddStudent}
              className="mt-10 grid gap-4 xl:grid-cols-[repeat(6,minmax(0,1fr))_200px]"
            >
              <input
                value={studentForm.id}
                onChange={(event) => setStudentForm((current) => ({ ...current, id: event.target.value }))}
                placeholder="Student ID"
                required
                className="rounded-2xl border border-[#d8e2ee] bg-[#fbfdff] px-5 py-4 text-lg outline-none transition focus:border-[#2563eb]"
              />
              <input
                value={studentForm.fname}
                onChange={(event) =>
                  setStudentForm((current) => ({ ...current, fname: event.target.value }))
                }
                placeholder="First name"
                required
                className="rounded-2xl border border-[#d8e2ee] bg-[#fbfdff] px-5 py-4 text-lg outline-none transition focus:border-[#2563eb]"
              />
              <input
                value={studentForm.lname}
                onChange={(event) =>
                  setStudentForm((current) => ({ ...current, lname: event.target.value }))
                }
                placeholder="Last name"
                required
                className="rounded-2xl border border-[#d8e2ee] bg-[#fbfdff] px-5 py-4 text-lg outline-none transition focus:border-[#2563eb]"
              />
              <input
                value={studentForm.email}
                onChange={(event) =>
                  setStudentForm((current) => ({ ...current, email: event.target.value }))
                }
                placeholder="Email"
                required
                className="rounded-2xl border border-[#d8e2ee] bg-[#fbfdff] px-5 py-4 text-lg outline-none transition focus:border-[#2563eb]"
              />
              <input
                value={studentForm.gpa}
                onChange={(event) =>
                  setStudentForm((current) => ({ ...current, gpa: event.target.value }))
                }
                placeholder="GPA"
                required
                className="rounded-2xl border border-[#d8e2ee] bg-[#fbfdff] px-5 py-4 text-lg outline-none transition focus:border-[#2563eb]"
              />
              <input
                value={studentForm.parentNum}
                onChange={(event) =>
                  setStudentForm((current) => ({ ...current, parentNum: event.target.value }))
                }
                placeholder="Parent number"
                required
                className="rounded-2xl border border-[#d8e2ee] bg-[#fbfdff] px-5 py-4 text-lg outline-none transition focus:border-[#2563eb]"
              />
              <button className="rounded-2xl bg-[linear-gradient(135deg,#2563eb,#0f172a)] px-6 py-4 text-lg font-semibold text-white shadow-[0_18px_40px_rgba(37,99,235,0.22)] transition hover:brightness-105">
                + Add Student
              </button>
            </form>

            <p className="mt-4 text-sm text-[#64748b]">
              Optional middle name is omitted here to keep the demo cleaner. Parent number must
              match an existing `PARENT.Num`.
            </p>
            <p className="mt-2 text-sm text-[#2563eb]">{studentMessage}</p>

            <div className="mt-8 overflow-hidden rounded-[24px] border border-[#e2e8f0] bg-white shadow-[0_8px_24px_rgba(148,163,184,0.08)]">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead className="bg-[#f8fafc]">
                    <tr>
                      {["Student_ID", "First_Name", "Last_Name", "Email", "GPA", "Parent_Num", "Action"].map(
                        (heading) => (
                          <th
                            key={heading}
                            className="border-b border-[#e5edf5] px-7 py-5 text-left text-xs font-semibold uppercase tracking-[0.18em] text-[#475569]"
                          >
                            {heading}
                          </th>
                        ),
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((student) => (
                      <tr key={student.ID} className="border-b border-[#eef2f7]">
                        <td className="px-7 py-5 text-2xl text-[#0f172a]">{student.ID}</td>
                        <td className="px-7 py-5 text-2xl text-[#0f172a]">{student.Fname}</td>
                        <td className="px-7 py-5 text-2xl text-[#0f172a]">{student.Lname}</td>
                        <td className="px-7 py-5 text-xl text-[#334155]">{student.Email}</td>
                        <td className="px-7 py-5 text-xl text-[#334155]">{student.GPA}</td>
                        <td className="px-7 py-5 text-xl text-[#334155]">{student.Parent_Num}</td>
                        <td className="px-7 py-5">
                          <button
                            onClick={() => void handleDeleteStudent(student.ID)}
                            className="rounded-xl border border-[#fecaca] bg-[#fff5f5] px-5 py-3 text-lg font-semibold text-[#dc2626] transition hover:bg-[#ffe4e6]"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                    {!loadingStudents && students.length === 0 ? (
                      <tr>
                        <td className="px-7 py-8 text-lg text-[#64748b]" colSpan={7}>
                          No students found.
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        ) : null}

        {activeTab === "enrollments" ? (
          <section className="rounded-[30px] border border-[#e3ebf5] bg-white p-8 shadow-[0_24px_60px_rgba(148,163,184,0.10)]">
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#2563eb]">
              Relational Data
            </p>
            <h2 className="mt-3 font-display text-5xl font-bold tracking-[-0.04em] text-[#0f172a]">
              Enrollments
            </h2>
            <p className="mt-4 max-w-3xl text-lg text-[#64748b]">
              Add enrollment rows connected to existing students and courses, then inspect the
              joined relationship from the backend.
            </p>

            <form
              onSubmit={handleAddEnrollment}
              className="mt-10 grid gap-4 xl:grid-cols-[1fr_1fr_240px]"
            >
              <input
                value={enrollmentForm.studentId}
                onChange={(event) =>
                  setEnrollmentForm((current) => ({ ...current, studentId: event.target.value }))
                }
                placeholder="student_id (existing)"
                required
                className="rounded-2xl border border-[#d8e2ee] bg-[#fbfdff] px-5 py-4 text-lg outline-none transition focus:border-[#2563eb]"
              />
              <input
                value={enrollmentForm.courseId}
                onChange={(event) =>
                  setEnrollmentForm((current) => ({ ...current, courseId: event.target.value }))
                }
                placeholder="course_id (existing)"
                required
                className="rounded-2xl border border-[#d8e2ee] bg-[#fbfdff] px-5 py-4 text-lg outline-none transition focus:border-[#2563eb]"
              />
              <button className="rounded-2xl bg-[linear-gradient(135deg,#2563eb,#0f172a)] px-6 py-4 text-lg font-semibold text-white shadow-[0_18px_40px_rgba(37,99,235,0.22)] transition hover:brightness-105">
                + Add Enrollment
              </button>
            </form>

            <p className="mt-2 text-sm text-[#2563eb]">{enrollmentMessage}</p>

            <div className="mt-8 overflow-hidden rounded-[24px] border border-[#e2e8f0] bg-white shadow-[0_8px_24px_rgba(148,163,184,0.08)]">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead className="bg-[#f7fafc]">
                    <tr>
                      {["Student_ID", "Student_Name", "Course_ID", "Course_Name", "Action"].map(
                        (heading) => (
                          <th
                            key={heading}
                            className="border-b border-[#e5edf5] px-7 py-5 text-left text-xs font-semibold uppercase tracking-[0.18em] text-[#475569]"
                          >
                            {heading}
                          </th>
                        ),
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    {enrollments.map((row) => (
                      <tr key={`${row.Student_ID}-${row.Course_ID}`} className="border-b border-[#eef2f7]">
                        <td className="px-7 py-5 text-2xl text-[#0f172a]">{row.Student_ID}</td>
                        <td className="px-7 py-5 text-2xl text-[#0f172a]">{row.Student_Name}</td>
                        <td className="px-7 py-5 text-2xl text-[#0f172a]">{row.Course_ID}</td>
                        <td className="px-7 py-5 text-xl text-[#334155]">{row.Course_Name}</td>
                        <td className="px-7 py-5">
                          <button
                            onClick={() => void handleDeleteEnrollment(row.Student_ID, row.Course_ID)}
                            className="rounded-xl border border-[#fecaca] bg-[#fff5f5] px-5 py-3 text-lg font-semibold text-[#dc2626] transition hover:bg-[#ffe4e6]"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                    {!loadingEnrollments && enrollments.length === 0 ? (
                      <tr>
                        <td className="px-7 py-8 text-lg text-[#64748b]" colSpan={5}>
                          No enrollments found.
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        ) : null}

        {activeTab === "queries" ? (
          <section className="rounded-[30px] border border-[#e3ebf5] bg-white p-8 shadow-[0_24px_60px_rgba(148,163,184,0.10)]">
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#2563eb]">
              SQL Explorer
            </p>
            <h2 className="mt-3 font-display text-5xl font-bold tracking-[-0.04em] text-[#0f172a]">
              Query Explorer
            </h2>
            <p className="mt-4 max-w-3xl text-lg text-[#64748b]">
              Enter a query number from 1 to 10 and load just that SQL with its live Railway MySQL result.
            </p>

            <div className="mt-10 flex flex-wrap items-center gap-5">
              <input
                value={queryIdInput}
                onChange={(event) => setQueryIdInput(event.target.value.replace(/\D/g, ""))}
                className="w-[320px] rounded-2xl border border-[#d8e2ee] bg-[#fbfdff] px-6 py-4 text-2xl outline-none transition focus:border-[#2563eb]"
                placeholder="Enter query number (1-10)"
              />
              <button
                onClick={() => void runQuery()}
                className="rounded-2xl bg-[linear-gradient(135deg,#2563eb,#0f172a)] px-10 py-4 text-xl font-semibold text-white shadow-[0_18px_40px_rgba(37,99,235,0.22)] transition hover:brightness-105"
              >
                {loadingQuery ? "Running..." : "Run Query"}
              </button>
              <p className="text-xl text-[#64748b]">Use `1` to `10`.</p>
            </div>

            <p className="mt-5 text-sm text-[#2563eb]">{queryMessage}</p>

            {selectedQuery ? (
              <>
                <div className="mt-6 rounded-[24px] border border-[#e2e8f0] bg-[#fbfdff] p-7 shadow-[0_8px_24px_rgba(148,163,184,0.08)]">
                  <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#2563eb]">
                    {selectedQuery.category} Query
                  </p>
                  <h3 className="mt-2 font-display text-3xl font-semibold text-[#0f172a]">
                    {selectedQuery.title}
                  </h3>
                  <p className="mt-3 text-lg text-[#64748b]">{selectedQuery.summary}</p>
                  <pre className="mt-5 overflow-x-auto rounded-[24px] bg-[#0f172a] px-6 py-6 text-base leading-8 text-[#e2e8f0]">
                    {selectedQuery.sql}
                  </pre>
                </div>

                <div className="mt-5 rounded-[24px] bg-[#0f172a] px-8 py-8 text-[#e2e8f0] shadow-[0_20px_50px_rgba(15,23,42,0.20)]">
                  <pre className="overflow-x-auto whitespace-pre-wrap text-lg leading-8">
                    {queryPreviewJson}
                  </pre>
                </div>

                {queryColumns.length > 0 ? (
                  <div className="mt-8 overflow-hidden rounded-[24px] border border-[#e2e8f0] bg-white shadow-[0_8px_24px_rgba(148,163,184,0.08)]">
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse">
                        <thead className="bg-[#f7fafc]">
                          <tr>
                            {queryColumns.map((heading) => (
                              <th
                                key={heading}
                                className="border-b border-[#e5edf5] px-7 py-5 text-left text-xs font-semibold uppercase tracking-[0.18em] text-[#475569]"
                              >
                                {heading}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {queryRows.map((row, index) => {
                            const values = Array.isArray(row)
                              ? row
                              : queryColumns.map((column) => row[column]);

                            return (
                              <tr key={`${selectedQueryId}-${index}`} className="border-b border-[#eef2f7]">
                                {values.map((value, valueIndex) => (
                                  <td
                                    key={`${selectedQueryId}-${index}-${valueIndex}`}
                                    className="px-7 py-5 text-lg text-[#334155]"
                                  >
                                    {value === null ? "NULL" : String(value)}
                                  </td>
                                ))}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : null}
              </>
            ) : (
              <div className="mt-6 rounded-[24px] border border-dashed border-[#d8e2ee] bg-[#fbfdff] px-8 py-14 text-center text-lg text-[#64748b]">
                Enter a query number and click `Run Query` to load its SQL and results.
              </div>
            )}
          </section>
        ) : null}
      </div>
    </main>
  );
}
