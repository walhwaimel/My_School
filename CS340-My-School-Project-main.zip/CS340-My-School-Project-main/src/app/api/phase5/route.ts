import { NextResponse } from "next/server";

import { getPhase5Query } from "@/lib/phase5/query-definitions";
import { runMutation, runSelectQuery } from "@/lib/mysql";

export const dynamic = "force-dynamic";

type Phase5Request = {
  queryId: string;
  values?: Record<string, string>;
};

function getColumns(rows: Record<string, unknown>[]) {
  return rows.length > 0 ? Object.keys(rows[0]) : [];
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Phase5Request;
    const query = getPhase5Query(body.queryId);

    if (!query) {
      return NextResponse.json({ error: "Unknown phase 5 query." }, { status: 400 });
    }

    if (query.mode === "select") {
      const rows = await runSelectQuery(query.sql);

      return NextResponse.json({
        columns: getColumns(rows),
        rows,
        message: `${rows.length} row${rows.length === 1 ? "" : "s"} returned.`,
      });
    }

    if (query.id === "q4") {
      const values = body.values ?? {};
      const params = [
        Number(values.id),
        values.fname,
        values.mname || null,
        values.lname,
        values.email,
        Number(values.gpa),
        Number(values.parentNum),
      ];

      await runMutation(query.sql, params);

      const rows = await runSelectQuery(
        `SELECT ID, Fname, Mname, Lname, Email, GPA, Parent_Num
         FROM STUDENT
         WHERE ID = ?`,
        [Number(values.id)],
      );

      return NextResponse.json({
        columns: getColumns(rows),
        rows,
        message: "Student inserted successfully.",
      });
    }

    if (query.id === "q5") {
      const values = body.values ?? {};
      const studentId = Number(values.id);

      const existing = await runSelectQuery(
        `SELECT ID, Fname, Lname, Email
         FROM STUDENT
         WHERE ID = ?`,
        [studentId],
      );

      const result = await runMutation(query.sql, [studentId]);

      return NextResponse.json({
        columns: ["Deleted_ID", "Affected_Rows", "Deleted_Student"],
        rows: [
          [
            studentId,
            result.affectedRows,
            existing[0] ? `${existing[0].Fname} ${existing[0].Lname}` : "Not found",
          ],
        ],
        message:
          result.affectedRows > 0
            ? "Student deleted successfully."
            : "No student was deleted. Check the ID and try again.",
      });
    }

    return NextResponse.json({ error: "Unsupported phase 5 action." }, { status: 400 });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Something went wrong while running the query.";

    return NextResponse.json({ error: message }, { status: 500 });
  }
}
