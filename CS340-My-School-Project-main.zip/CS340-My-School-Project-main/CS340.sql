CREATE DATABASE  IF NOT EXISTS `myschool_phase5` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `myschool_phase5`;
-- MySQL dump 10.13  Distrib 8.0.45, for macos15 (arm64)
--
-- Host: metro.proxy.rlwy.net    Database: myschool_phase5
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ADMIN`
--

DROP TABLE IF EXISTS `ADMIN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ADMIN` (
  `ID` int NOT NULL,
  `Fname` varchar(50) NOT NULL,
  `Lname` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ADMIN`
--

LOCK TABLES `ADMIN` WRITE;
/*!40000 ALTER TABLE `ADMIN` DISABLE KEYS */;
INSERT INTO `ADMIN` VALUES (10001,'Sara','Ali','sara_admin','123'),(10002,'Noor','Hassan','noor_admin','123'),(10003,'Lama','Khalid','lama_admin','123'),(10004,'Reem','Saad','reem_admin','123'),(10005,'Huda','Fahad','huda_admin','123'),(10006,'Abeer','Nasser','abeer_admin','123'),(10007,'Maha','Omar','maha_admin','123'),(10008,'Dalia','Salem','dalia_admin','123'),(10009,'Rana','Tariq','rana_admin','123'),(10010,'Eman','Adel','eman_admin','123');
/*!40000 ALTER TABLE `ADMIN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COURSE`
--

DROP TABLE IF EXISTS `COURSE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COURSE` (
  `ID` int NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Teacher_ID` int DEFAULT NULL,
  `Admin_ID` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Teacher_ID` (`Teacher_ID`),
  KEY `Admin_ID` (`Admin_ID`),
  CONSTRAINT `COURSE_ibfk_1` FOREIGN KEY (`Teacher_ID`) REFERENCES `TEACHER` (`ID`),
  CONSTRAINT `COURSE_ibfk_2` FOREIGN KEY (`Admin_ID`) REFERENCES `ADMIN` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COURSE`
--

LOCK TABLES `COURSE` WRITE;
/*!40000 ALTER TABLE `COURSE` DISABLE KEYS */;
INSERT INTO `COURSE` VALUES (401,'Mathematics',30001,10001),(402,'English',30002,10002),(403,'Science',30003,10003),(404,'History',30004,10004),(405,'Physics',30005,10005),(406,'Chemistry',30006,10006),(407,'Biology',30007,10007),(408,'Computer',30008,10008),(409,'Art',30009,10009),(410,'PE',30010,10010);
/*!40000 ALTER TABLE `COURSE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ENROLLMENT`
--

DROP TABLE IF EXISTS `ENROLLMENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ENROLLMENT` (
  `Student_ID` int NOT NULL,
  `Course_ID` int NOT NULL,
  PRIMARY KEY (`Student_ID`,`Course_ID`),
  KEY `Course_ID` (`Course_ID`),
  CONSTRAINT `ENROLLMENT_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `STUDENT` (`ID`),
  CONSTRAINT `ENROLLMENT_ibfk_2` FOREIGN KEY (`Course_ID`) REFERENCES `COURSE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ENROLLMENT`
--

LOCK TABLES `ENROLLMENT` WRITE;
/*!40000 ALTER TABLE `ENROLLMENT` DISABLE KEYS */;
INSERT INTO `ENROLLMENT` VALUES (22201,401),(22203,401),(22204,401),(22201,402),(22202,402),(22205,402),(22202,403),(22210,403),(22203,404),(22206,404),(22204,405),(22207,405),(22205,406),(22208,406),(22206,407),(22209,407),(22207,408),(22210,408),(22208,409),(22209,410);
/*!40000 ALTER TABLE `ENROLLMENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PARENT`
--

DROP TABLE IF EXISTS `PARENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PARENT` (
  `Num` int NOT NULL,
  `Parent_Name` varchar(100) NOT NULL,
  `Relationship_with_student` varchar(50) NOT NULL,
  PRIMARY KEY (`Num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PARENT`
--

LOCK TABLES `PARENT` WRITE;
/*!40000 ALTER TABLE `PARENT` DISABLE KEYS */;
INSERT INTO `PARENT` VALUES (50001,'Saud Alotaibi','Father'),(50002,'Noura Almutairi','Mother'),(50003,'Khalid Alqahtani','Father'),(50004,'Maha Alanazi','Mother'),(50005,'Fahad Alharbi','Father'),(50006,'Amal Alshammari','Mother'),(50007,'Sultan Alzahrani','Father'),(50008,'Hessa Alghamdi','Mother'),(50009,'Turki Alrashidi','Father'),(50010,'Latifa Alotaibi','Mother');
/*!40000 ALTER TABLE `PARENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STUDENT`
--

DROP TABLE IF EXISTS `STUDENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `STUDENT` (
  `ID` int NOT NULL,
  `Fname` varchar(50) NOT NULL,
  `Mname` varchar(50) DEFAULT NULL,
  `Lname` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `GPA` decimal(4,2) NOT NULL,
  `Parent_Num` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Email` (`Email`),
  KEY `Parent_Num` (`Parent_Num`),
  CONSTRAINT `STUDENT_ibfk_1` FOREIGN KEY (`Parent_Num`) REFERENCES `PARENT` (`Num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STUDENT`
--

LOCK TABLES `STUDENT` WRITE;
/*!40000 ALTER TABLE `STUDENT` DISABLE KEYS */;
INSERT INTO `STUDENT` VALUES (22201,'Layan','A','Alotaibi','layan1@mail.com',3.50,50001),(22202,'Reem','B','Almutairi','reem2@mail.com',3.80,50002),(22203,'Nada','C','Alqahtani','nada3@mail.com',4.00,50003),(22204,'Huda','D','Alanazi','huda4@mail.com',3.20,50004),(22205,'Rana','E','Alharbi','rana5@mail.com',3.60,50005),(22206,'Maha','F','Alshammari','maha6@mail.com',3.90,50006),(22207,'Abeer','G','Alzahrani','abeer7@mail.com',3.70,50007),(22208,'Noor','H','Alghamdi','noor8@mail.com',3.30,50008),(22209,'Sara','I','Alrashidi','sara9@mail.com',3.85,50009),(22210,'Dalia','J','Alotaibi','dalia10@mail.com',3.40,50010);
/*!40000 ALTER TABLE `STUDENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TEACHER`
--

DROP TABLE IF EXISTS `TEACHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TEACHER` (
  `ID` int NOT NULL,
  `Fname` varchar(50) NOT NULL,
  `Lname` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `Admin_ID` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Email` (`Email`),
  KEY `Admin_ID` (`Admin_ID`),
  CONSTRAINT `TEACHER_ibfk_1` FOREIGN KEY (`Admin_ID`) REFERENCES `ADMIN` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TEACHER`
--

LOCK TABLES `TEACHER` WRITE;
/*!40000 ALTER TABLE `TEACHER` DISABLE KEYS */;
INSERT INTO `TEACHER` VALUES (30001,'Fatimah','Ali','fatimah@mail.com','0501111111',10001),(30002,'Aisha','Hassan','aisha@mail.com','0502222222',10002),(30003,'Nora','Khalid','nora@mail.com','0503333333',10003),(30004,'Lama','Saad','lama@mail.com','0504444444',10004),(30005,'Reem','Fahad','reem@mail.com','0505555555',10005),(30006,'Huda','Omar','huda@mail.com','0506666666',10006),(30007,'Sara','Nasser','sara@mail.com','0507777777',10007),(30008,'Maha','Salem','maha@mail.com','0508888888',10008),(30009,'Dalia','Ali','dalia@mail.com','0509999999',10009),(30010,'Noor','Adel','noor@mail.com','0510000000',10010);
/*!40000 ALTER TABLE `TEACHER` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-11 19:26:49
